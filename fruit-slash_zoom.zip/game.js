(() => {
  'use strict';

  /* =====================================================
     Helpers
  ===================================================== */
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rand = (a, b) => a + Math.random() * (b - a);
  // admin cheat flags (changed only by the PIN protected console in admin.js)
  const adm = { god: false, auto: false, noBombs: false, freeze: false, mult: 1, speed: 1, rate: 1, fps: 60 };
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* =====================================================
     Content: weapons, backgrounds, fruits, sounds
     (add your own by copying a line and changing the file path)
  ===================================================== */
  // price = coins needed in the shop (0 = you own it from the start)
  // pixel:true keeps pixel-art crisp. frames/fw/fh/fps describe an animated strip.
  const WEAPONS = [
    { id: 'katana',               name: 'Samurai katana',            desc: 'Sharp, clean and fast.',          img: 'assets/weapons/katana.png',               trail: '#ffffff', glow: '#9fd8ff', price: 0 },
    { id: 'silver-blade',         name: 'Silver blade',              desc: 'Plain steel with a blue gem.',    img: 'assets/weapons/silver-blade.png',         trail: '#ffffff', glow: '#6ec1ff', price: 100,  pixel: true },
    { id: 'crystal-sword',        name: 'Crystal sword',             desc: 'Glassy edge, ice-blue grip.',     img: 'assets/weapons/crystal-sword.png',        trail: '#e8f7ff', glow: '#2fb4ff', price: 250,  pixel: true },
    { id: 'night-king-ice-blade', name: 'Ice blade',                 desc: 'Leaves a freezing trail.',        img: 'assets/weapons/night-king-ice-blade.png', trail: '#e6f7ff', glow: '#3fc4ff', price: 400 },
    { id: 'finn-sword',            name: "Finn's sword",              desc: 'Mathematical! Adventure time.',   img: 'assets/weapons/finn-sword.png',           trail: '#e8fbff', glow: '#4fc3ff', price: 300,  hx: 2, hy: 2 },
    { id: 'netherite-sword',      name: 'Enchanted netherite sword', desc: 'Glows with purple magic.',        img: 'assets/weapons/netherite-sword.png',      trail: '#f1dcff', glow: '#b052ff', price: 600,  pixel: true },
    { id: 'ceruledge-blade',      name: 'Ceruledge blade',           desc: 'A blue spirit flame.',            img: 'assets/weapons/ceruledge-blade.png',      trail: '#e3f0ff', glow: '#5b7bff', price: 800 },
    { id: 'rey-lightsaber',        name: "Rey's lightsaber",          desc: 'An elegant weapon, glowing blue.', img: 'assets/weapons/rey-lightsaber.png',      trail: '#d8f0ff', glow: '#2a8bff', price: 700,  hx: 6, hy: 2 },
    { id: 'zangetsu',             name: 'Zangetsu',                  desc: 'A black blade with a flowing chain.', img: 'assets/weapons/zangetsu.png',          trail: '#e9e9ff', glow: '#6a5cff', price: 900,  frames: 2, fw: 128, fh: 122, fps: 2, hx: 2, hy: 2 },
    { id: 'neon-cyber-blade',     name: 'Neon cyber blade',          desc: 'Cyan and pink light.',            img: 'assets/weapons/neon-cyber-blade.png',     trail: '#ffffff', glow: '#ff3df2', price: 1000 },
    { id: 'enchanted-diamond',     name: 'Enchanted diamond sword',   desc: 'Pixel sparkle, purple glint.',    img: 'assets/weapons/enchanted-diamond.png',    trail: '#d9ffff', glow: '#7a5cff', price: 1200, pixel: true, frames: 8, fw: 128, fh: 128, fps: 10, hx: 2, hy: 2 },
    { id: 'rengoku-nichirin',     name: "Rengoku's nichirin",        desc: 'Flame Hashira blade.',            img: 'assets/weapons/rengoku-nichirin.png',     trail: '#ffe3c2', glow: '#ff6a1a', price: 1300, frames: 10, fw: 126, fh: 121, fps: 6.67, hx: 10, hy: 5 },
    { id: 'zoro-king-of-hell',    name: "Zoro's King of Hell",       desc: 'Wrapped in green demon aura.',    img: 'assets/weapons/zoro-king-of-hell.png',    trail: '#d6ffe6', glow: '#22d36b', price: 1400, frames: 8, fw: 100, fh: 128, fps: 8.57, hx: 8, hy: 8 },
    { id: 'kamish-wrath',         name: "Kamish's wrath",            desc: 'Red blade wrapped in purple fire.', img: 'assets/weapons/kamish-wrath.png',       trail: '#ffd6d6', glow: '#a62bff', price: 1500, frames: 32, fw: 52, fh: 62, fps: 30 },
    { id: 'fionna-crystal-sword', name: "Fionna's crystal sword", desc: 'Pink crystal from Aaa.', img: 'assets/weapons/fionna-crystal-sword.png', trail: '#ffd6f2', glow: '#ff5fd0', price: 350, hx: 2, hy: 2 },
    { id: 'demon-blood-sword', name: "Demon blood sword", desc: 'Pixel blade dripping red.', img: 'assets/weapons/demon-blood-sword.png', trail: '#ffd0d0', glow: '#ff2a2a', price: 450, pixel: true, hx: 4, hy: 4 },
    { id: 'sanemi-nichirin', name: "Sanemi's nichirin", desc: 'Wind Hashira blade.', img: 'assets/weapons/sanemi-nichirin.png', trail: '#d6ffe0', glow: '#3dff7a', price: 950, frames: 6, fw: 127, fh: 127, fps: 6.67, hx: 2, hy: 4 },
    { id: 'zoro-three-swords', name: "Zoro's three swords", desc: 'Santoryu, all three at once.', img: 'assets/weapons/zoro-three-swords.png', trail: '#ffffff', glow: '#ff4d4d', price: 1100, frames: 7, fw: 128, fh: 128, fps: 5.0, hx: 2, hy: 2 },
    { id: 'kokushibo-katana', name: "Kokushibo's moon blade", desc: 'Upper Moon One, six eyes.', img: 'assets/weapons/kokushibo-katana.png', trail: '#ffc9d4', glow: '#ff3b6b', price: 1250, frames: 5, fw: 128, fh: 128, fps: 8.57, hx: 2, hy: 6 },
    { id: 'royal-gold-blade', name: 'Royal gold blade', desc: 'Game Pass level 100 reward.', img: 'assets/weapons/royal-gold-blade.png', trail: '#fff3b0', glow: '#ffcf3d', price: 99999, passOnly: true }
  ];

  // every weapon has its own ability while you hold it (hooks are in sliceFruit, explode, update and handleSegment)
  const ABILITY = {
    'katana':               ['Perfect cut',      'Every 7th slice scores double.'],
    'silver-blade':         ['Steel reach',      'Wider hit area: +35%.'],
    'crystal-sword':        ['Chain cut',        'Slicing also cuts the nearest fruit.'],
    'night-king-ice-blade': ['Frostbite',        '12% chance to freeze time for 2s.'],
    'finn-sword':           ['Adventure time',   'Your combo timer lasts much longer.'],
    'netherite-sword':      ['Netherite armor',  'Blocks the first bomb each round.'],
    'ceruledge-blade':      ['Soul flame',       'Every 25 slices restores a life.'],
    'rey-lightsaber':       ['The Force',        'Fruit fall 20% slower.'],
    'zangetsu':             ['Getsuga',          'Every 15 slices cuts all fruit on screen.'],
    'neon-cyber-blade':     ['Overclock',        'Combo multiplier grows faster (up to x6).'],
    'enchanted-diamond':    ['Fortune',          '20% chance of +3 bonus coins per slice.'],
    'rengoku-nichirin':     ['Flame breathing',  'x1.5 points while your combo is 10+.'],
    'zoro-king-of-hell':    ['Oni giri',         'Safely cut up to 3 bombs per round.'],
    'kamish-wrath':         ['Dragon fire',      '8% chance of a fire burst that cuts nearby fruit.'],
    'fionna-crystal-sword': ['Cake\'s blessing', '4% chance a slice starts a Frenzy.'],
    'demon-blood-sword':    ['Blood harvest',    '+2 coins per slice while your combo is 5+.'],
    'sanemi-nichirin':      ['Wind breathing',   '18% chance a gust cuts all fruit near the slice.'],
    'zoro-three-swords':    ['Santoryu',         'Every 10th slice cuts a wide circle of fruit.'],
    'kokushibo-katana':     ['Six eyes',         'Combo timer lasts 30% longer and +1 point per slice.'],
    'royal-gold-blade':     ['Midas touch',      'Double coins from every fruit.']
  };
  const abilityLine = id => ABILITY[id] ? '★ ' + ABILITY[id][0] + ': ' + ABILITY[id][1] : '';

  const BACKGROUNDS = [
    { name: 'Orchard valley',    src: 'assets/backgrounds/orchard.jpg' },
    { name: 'Frozen citadel',    src: 'assets/backgrounds/ice.jpg' },
    { name: 'Neon night market', src: 'assets/backgrounds/city.jpg' },
    { name: 'Volcano forge',     src: 'assets/backgrounds/lava.jpg' },
    { name: 'Blood moon shrine', src: 'assets/backgrounds/shrine.jpg' },
    { name: 'Eruption ridge',    src: 'assets/backgrounds/eruption.jpg' },
    { name: 'Glow-moss forest',  src: 'assets/backgrounds/rayman-forest.jpg' },
    { name: 'Pixel kingdom',     src: 'assets/backgrounds/pixel-kingdom.jpg' },
    { name: 'Pixel meadow',      src: 'assets/backgrounds/pixel-meadow.jpg' },
    { name: 'Torch dungeon',     src: 'assets/backgrounds/torch-dungeon.jpg' },
    { name: 'Pixel woodland',    src: 'assets/backgrounds/pixel-forest.jpg' }
  ];

  // pts = score for slicing it, coins = money you earn
  const FRUITS = {
    apple:      { src: 'assets/fruits/apple.png',      pts: 1, coins: 1, pixel: true,  juice: ['#e8383d', '#ff8a8a', '#8a1018'] },
    orange:     { src: 'assets/fruits/orange.png',     pts: 1, coins: 1, pixel: true,  juice: ['#ff9f1a', '#ffd27a', '#c46d00'] },
    watermelon: { src: 'assets/fruits/watermelon.png', pts: 1, coins: 2, pixel: true,  juice: ['#ff4a5a', '#3fae4b', '#ffd0d0'] },
    strawberry: { src: 'assets/fruits/strawberry.png', pts: 1, coins: 2, pixel: true,  juice: ['#ff0014', '#fff3c0', '#a00000'] },
    cherry:     { src: 'assets/fruits/cherry.png',     pts: 2, coins: 3, pixel: false, juice: ['#c8102e', '#7a0a22', '#ff6b7a'] },
    banana:     { src: 'assets/fruits/banana.png',     pts: 1, coins: 1, pixel: true,  juice: ['#ffd93b', '#fff0a0', '#d89a00'] },
    greenapple: { src: 'assets/fruits/greenapple.png', pts: 1, coins: 1, pixel: true,  juice: ['#7ed957', '#d6f5a0', '#2e8b2e'] },
    peach:      { src: 'assets/fruits/peach.png',      pts: 1, coins: 2, pixel: true,  juice: ['#ff9aa2', '#ffd1d1', '#e0606e'] },
    melonslice: { src: 'assets/fruits/melonslice.png', pts: 1, coins: 2, pixel: true,  juice: ['#ff4a5a', '#0fe8a8', '#ffd0d0'] },
    grapes:     { src: 'assets/fruits/grapes.png',     pts: 2, coins: 3, pixel: true,  juice: ['#8e3fa0', '#d98ad0', '#4a1a5c'] },
    avocado:    { src: 'assets/fruits/avocado.png',    pts: 2, coins: 3, pixel: false, juice: ['#c8e04a', '#f2f58a', '#5a8a1a'] }
  };
  // how often each fruit appears (cherries are rarer)
  const FRUIT_POOL = ['apple', 'apple', 'orange', 'orange', 'watermelon', 'watermelon', 'strawberry', 'strawberry', 'banana', 'banana', 'greenapple', 'greenapple', 'peach', 'melonslice', 'grapes', 'avocado', 'cherry'];
  const GOLDEN_COINS = 10;

  const SOUND_FILES = {
    slice:     'assets/sounds/slice.mp3',
    explosion: 'assets/sounds/explosion.mp3',
    powerup:   'assets/sounds/powerup.mp3',
    rage:      'assets/sounds/rage.mp3',
    nocoins:   'assets/sounds/no-coins.mp3'
  };

  // background music (looped); players pick a track in Settings
  const MUSIC_TRACKS = [
    { id: 'funk-eclipse',       name: 'Funk Eclipse',          src: 'assets/sounds/funk-eclipse.mp3' },
    { id: 'brega-do-love',      name: 'Brega do Love',         src: 'assets/sounds/brega-do-love.mp3' },
    { id: 'montagem-guerreiro', name: 'Montagem Guerreiro',    src: 'assets/sounds/montagem-guerreiro.mp3' },
    { id: 'funk-abnormal',      name: 'Funk Abnormal (DJ V12)', src: 'assets/sounds/funk-abnormal.mp3' },
    { id: 'montagem-alquimia',  name: 'Montagem Alquimia',     src: 'assets/sounds/montagem-alquimia.mp3' },
    { id: 'montagem-bailao',    name: 'Montagem Bailao',       src: 'assets/sounds/montagem-bailao.mp3' },
    { id: 'montagem-uranium',   name: 'Montagem Uranium (slowed)', src: 'assets/sounds/montagem-uranium.mp3' },
    { id: 'nada-nada',          name: 'Nada Nada',             src: 'assets/sounds/nada-nada.mp3' },
    { id: 'ritmo-de-verao',     name: 'Ritmo de Verao (slowed)', src: 'assets/sounds/ritmo-de-verao.mp3' },
    { id: 'passo-bem-solto',    name: 'Passo Bem Solto (slowed)', src: 'assets/sounds/passo-bem-solto.mp3' },
    { id: 'luz-roja',           name: 'Luz Roja (slowed)',     src: 'assets/sounds/luz-roja.mp3' },
    { id: 'clima-lindo',        name: 'Clima Lindo (slowed)',  src: 'assets/sounds/clima-lindo.mp3' },
    { id: 'los-voltaje',        name: 'Los Voltaje',           src: 'assets/sounds/los-voltaje.mp3' }
  ];

  const DIFFICULTY = {
    easy:   { lives: 5, interval: 1.55, bomb: 0.04 },
    normal: { lives: 3, interval: 1.25, bomb: 0.10 },
    hard:   { lives: 3, interval: 0.95, bomb: 0.17 }
  };

  /* =====================================================
     Settings (saved in the browser)
  ===================================================== */
  const ZOOM_MIN = 0.6, ZOOM_MAX = 1.8, ZOOM_STEP = 0.1;   // game zoom range (1 = normal)
  const STORE_KEY = 'fruitSlash.v1';
  const DEFAULTS = {
    sound: true, volume: 0.7, music: true, musicVolume: 0.4, track: 'funk-eclipse', trail: true, weaponSize: 1, zoom: 1,
    bgSeconds: 60, difficulty: 'normal', weapon: 'katana', best: 0,
    coins: 0, owned: ['katana'],
    xp: 0, name: 'Player', scores: [],
    tickets: 0, lastFree: 0, pending: null,
    gold: 0, pass: false, passXp: 0, passDone: 0,
    pid: '', banned: false, banReason: '', note: '', created: 0, lastSeen: 0
  };
  let settings = { ...DEFAULTS };
  try { Object.assign(settings, JSON.parse(localStorage.getItem(STORE_KEY) || '{}')); } catch (e) { /* ignore */ }
  const ROSTER_KEY = 'fruitSlash.roster.v1';
  const PID_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const PID_RE = /^FS-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
  function makePid() {
    let r = '';
    for (let i = 0; i < 8; i++) r += PID_CHARS[Math.floor(Math.random() * PID_CHARS.length)];
    return 'FS-' + r.slice(0, 4) + '-' + r.slice(4);
  }
  function sanitizeSettings() {
  if (!DIFFICULTY[settings.difficulty]) settings.difficulty = DEFAULTS.difficulty;
  if (settings.track !== 'shuffle' && !MUSIC_TRACKS.some(t => t.id === settings.track)) settings.track = DEFAULTS.track;
  settings.musicVolume = clamp(+settings.musicVolume || 0, 0, 1);
  settings.coins = Math.max(0, Math.floor(+settings.coins || 0));
  settings.owned = (Array.isArray(settings.owned) ? settings.owned : []).filter(id => WEAPONS.some(w => w.id === id));
  WEAPONS.forEach(w => { if (w.price === 0 && !settings.owned.includes(w.id)) settings.owned.push(w.id); });
  if (!settings.owned.includes(settings.weapon)) settings.weapon = DEFAULTS.weapon;
  settings.zoom = clamp(Math.round((+settings.zoom || 1) * 100) / 100, ZOOM_MIN, ZOOM_MAX);
  settings.xp = Math.max(0, Math.floor(+settings.xp || 0));
  settings.name = String(settings.name || 'Player').slice(0, 14);
  settings.tickets = Math.max(0, Math.floor(+settings.tickets || 0));
  settings.lastFree = +settings.lastFree || 0;
  settings.gold = Math.max(0, Math.floor(+settings.gold || 0)); settings.pass = !!settings.pass;
  settings.passXp = Math.max(0, Math.floor(+settings.passXp || 0)); settings.passDone = clamp(Math.floor(+settings.passDone || 0), 0, 100);
  if (!(Number.isInteger(settings.pending) && settings.pending >= 0 && settings.pending < 8)) settings.pending = null;
  settings.scores = (Array.isArray(settings.scores) ? settings.scores : [])
    .filter(e => e && typeof e.score === 'number' && DIFFICULTY[e.diff]);
    settings.pid = PID_RE.test(String(settings.pid || '').toUpperCase()) ? String(settings.pid).toUpperCase() : makePid();
    settings.banned = !!settings.banned;
    settings.banReason = settings.banned ? String(settings.banReason || '').slice(0, 80) : '';
    settings.note = String(settings.note || '').slice(0, 120);
    settings.created = +settings.created || Date.now();
    settings.lastSeen = +settings.lastSeen || 0;
  }
  sanitizeSettings();
  const save = () => {
    if (!PID_RE.test(String(settings.pid || ''))) settings.pid = makePid();   // e.g. after an admin full reset
    settings.lastSeen = Date.now();
    try { localStorage.setItem(STORE_KEY, JSON.stringify(settings)); } catch (e) { /* ignore */ }
    try {   // owner roster: one snapshot per player id on this device
      const r = JSON.parse(localStorage.getItem(ROSTER_KEY) || '{}');
      r[settings.pid] = JSON.parse(JSON.stringify(settings));
      localStorage.setItem(ROSTER_KEY, JSON.stringify(r));
    } catch (e) { /* ignore */ }
  };
  let saveTimer = 0;
  const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(save, 400); };
  window.addEventListener('pagehide', save);
  window.addEventListener('beforeunload', save);

  /* =====================================================
     Assets
  ===================================================== */
  const loadImg = src => { const i = new Image(); i.src = src; return i; };
  const fruitImg  = {}; Object.keys(FRUITS).forEach(k => fruitImg[k] = loadImg(FRUITS[k].src));
  // fallback art if a fruit PNG is missing from assets/fruits (add the real PNG and it takes over)
  const EMOJI = { banana: '🍌', peach: '🍑', melonslice: '🍉', grapes: '🍇' };
  Object.keys(EMOJI).forEach(k => {
    fruitImg[k].onerror = () => {
      const c = document.createElement('canvas'); c.width = c.height = 128;
      const x = c.getContext('2d'); x.font = '100px serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillText(EMOJI[k], 64, 72); fruitImg[k] = c; FRUITS[k].pixel = false;
    };
  });
  // special pickups: ice freezes time, heart gives a life
  const SPECIAL = {
    ice:   { pts: 2, coins: 2, juice: ['#bfefff', '#ffffff', '#4fc3ff'] },
    heart: { pts: 2, coins: 3, juice: ['#ff3d6e', '#ffb3c6', '#a0123a'] }
  };
  function specialArt(kind) {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const x = c.getContext('2d'); x.translate(64, 64);
    if (kind === 'ice') {
      const g = x.createRadialGradient(-12, -16, 4, 0, 0, 52); g.addColorStop(0, '#fff'); g.addColorStop(.5, '#8fdcff'); g.addColorStop(1, '#2a8bff');
      x.fillStyle = g; x.strokeStyle = '#d9f6ff'; x.lineWidth = 4; x.shadowColor = '#4fc3ff'; x.shadowBlur = 18;
      x.beginPath(); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 - Math.PI / 2; x.lineTo(Math.cos(a) * 50, Math.sin(a) * 50); }
      x.closePath(); x.fill(); x.stroke();
      x.shadowBlur = 0; x.strokeStyle = 'rgba(255,255,255,.8)'; x.lineWidth = 3;
      for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; x.beginPath(); x.moveTo(Math.cos(a) * 34, Math.sin(a) * 34); x.lineTo(-Math.cos(a) * 34, -Math.sin(a) * 34); x.stroke(); }
    } else {
      const g = x.createRadialGradient(-14, -18, 4, 0, 0, 56); g.addColorStop(0, '#ff9ab5'); g.addColorStop(.6, '#ff2d63'); g.addColorStop(1, '#a0123a');
      x.shadowColor = '#ff3d6e'; x.shadowBlur = 18; x.fillStyle = g;
      x.beginPath(); x.moveTo(0, 46); x.bezierCurveTo(-70, -2, -42, -50, 0, -18); x.bezierCurveTo(42, -50, 70, -2, 0, 46); x.fill();
      x.shadowBlur = 0; x.strokeStyle = '#fff'; x.globalAlpha = .6; x.lineWidth = 5; x.lineCap = 'round';
      x.beginPath(); x.arc(-4, -4, 26, Math.PI * 1.1, Math.PI * 1.45); x.stroke();
    }
    return c;
  }
  fruitImg.ice = specialArt('ice'); fruitImg.heart = specialArt('heart');
  const weaponImg = {}; WEAPONS.forEach(w => weaponImg[w.id] = loadImg(w.img));
  BACKGROUNDS.forEach(b => loadImg(b.src)); // preload so the change is smooth

  const sounds = {};
  Object.keys(SOUND_FILES).forEach(k => { const a = new Audio(SOUND_FILES[k]); a.preload = 'auto'; sounds[k] = a; });
  let rageAudio = null;
  function play(name, vol = 1, rate = 1) {
    if (!settings.sound) return null;
    try {
      const a = sounds[name].cloneNode();
      a.volume = clamp(settings.volume * vol, 0, 1);
      a.playbackRate = rate;
      const p = a.play(); if (p && p.catch) p.catch(() => {});
      return a;
    } catch (e) { return null; }
  }
  /* ---------- Background music ---------- */
  const bgm = new Audio(); bgm.loop = true; bgm.preload = 'auto';
  let bgmTrack = null, bgmUnlocked = false, shuffleId = null;
  const nextShuffle = () => {   // random track that is not the one that just played
    const pool = MUSIC_TRACKS.filter(t => t.id !== shuffleId);
    shuffleId = pool[Math.floor(Math.random() * pool.length)].id; return shuffleId;
  };
  bgm.addEventListener('ended', () => { if (settings.track === 'shuffle') applyMusic(); });
  function applyMusic() {
    bgm.volume = clamp(settings.musicVolume, 0, 1);
    if (!settings.music || !bgmUnlocked || document.hidden) { bgm.pause(); return; }
    const shuf = settings.track === 'shuffle';
    bgm.loop = !shuf;
    if (shuf && (!shuffleId || bgm.ended)) nextShuffle();
    const t = MUSIC_TRACKS.find(x => x.id === (shuf ? shuffleId : settings.track)) || MUSIC_TRACKS[0];
    if (bgmTrack !== t.id || bgm.ended) { bgmTrack = t.id; bgm.src = t.src; bgm.currentTime = 0; }
    const p = bgm.play(); if (p && p.catch) p.catch(() => {});
  }
  // browsers only allow audio after a tap/click, so start on the first one
  function unlockMusic() {
    bgmUnlocked = true; applyMusic();
    ['pointerdown', 'keydown', 'touchstart'].forEach(ev => window.removeEventListener(ev, unlockMusic, true));
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(ev => window.addEventListener(ev, unlockMusic, true));
  document.addEventListener('visibilitychange', applyMusic);

  function stopRage() { if (rageAudio) { try { rageAudio.pause(); } catch (e) {} rageAudio = null; } }

  /* =====================================================
     Screens
  ===================================================== */
  const body = document.body;
  const hud = $('#hud');
  function setScreen(name) { $$('.screen').forEach(s => s.classList.toggle('active', s.id === 'screen-' + name)); }
  function enterMenu(name = 'menu') {
    body.classList.add('in-menu'); body.classList.remove('playing');
    hud.hidden = true; setScreen(name);
    renderCoins(); renderLevel(); renderMenuInfo(); renderSpinUI(); renderPass();
    menuStart();
  }
  function renderMenuInfo() {
    $('#sub-play').textContent = settings.best > 0 ? 'Best score: ' + settings.best : 'Start slicing';
    $('#sub-weapons').textContent = 'Equipped: ' + weaponDef().name;
    const top = settings.scores.find(e => e.diff === settings.difficulty);
    $('#sub-board').textContent = top ? 'Top score: ' + top.score + ' (' + settings.difficulty + ')' : 'No scores yet';
    $('#sub-settings').textContent = 'Difficulty: ' + settings.difficulty + ', sound ' + (settings.sound ? 'on' : 'off');
    $('#pc-name').textContent = settings.name;
    $('#menu-arena').textContent = BACKGROUNDS[menuBgIndex].name;
  }

  /* ---------- Background (cross-fade between two layers) ---------- */
  const layers = [$('#bg-a'), $('#bg-b')];
  let activeLayer = 0;
  function setBackground(i, instant) {
    const cur = layers[activeLayer], next = layers[1 - activeLayer];
    next.style.backgroundImage = `url("${BACKGROUNDS[i].src}")`;
    if (instant) { next.style.transition = 'none'; cur.style.transition = 'none'; }
    next.classList.add('show'); cur.classList.remove('show');
    if (instant) { void next.offsetWidth; next.style.transition = ''; cur.style.transition = ''; }
    activeLayer = 1 - activeLayer;
  }
  let menuBgIndex = Math.floor(Math.random() * BACKGROUNDS.length);
  setBackground(menuBgIndex, true);

  /* ---------- Coins ---------- */
  const isOwned = id => settings.owned.includes(id);
  function renderCoins() {
    $$('[data-coins]').forEach(e => { e.textContent = settings.coins; });
    $$('[data-tickets]').forEach(e => { e.textContent = settings.tickets; });
    $('#hud-coins').textContent = settings.coins;
  }
  function addCoins(n, x, y) {
    if (n <= 0) return;
    settings.coins += n;
    if (G) {
      G.coinsEarned += n;
      const el = $('.hud-coins'); el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse');
      if (x != null) {
        const c = $('.hud-coins .coin').getBoundingClientRect();
        for (let i = 0; i < Math.min(n, 4); i++) {
          G.coinFx.push({ x0: x + rand(-14, 14), y0: y + rand(-14, 14), tx: (c.left + c.width / 2) / Z, ty: (c.top + c.height / 2) / Z, life: 0.7 + i * 0.06, max: 0.7 + i * 0.06 });
        }
      }
    }
    saveSoon(); renderCoins();
  }

  /* ---------- Levels ---------- */
  // XP needed to go from level n to n+1. Change this line to make levelling faster or slower.
  const xpForNext = lvl => 100 + 40 * (lvl - 1);
  const levelReward = lvl => 20 + 10 * lvl;          // coins you get for reaching a level
  function levelInfo(xp) {
    let level = 1, into = xp;
    while (into >= xpForNext(level)) { into -= xpForNext(level); level++; }
    return { level, into, need: xpForNext(level) };
  }
  function renderLevel() {
    const info = levelInfo(settings.xp), pct = (info.into / info.need * 100).toFixed(1) + '%';
    $$('[data-level]').forEach(e => { e.textContent = 'Level ' + info.level; });
    $$('[data-levelnum]').forEach(e => { e.textContent = info.level; });
    $$('[data-xpring]').forEach(e => { e.style.setProperty('--xp', (info.into / info.need * 360).toFixed(1) + 'deg'); });
    $$('[data-xpfill]').forEach(e => { e.style.width = pct; });
    $$('[data-xptext]').forEach(e => { e.textContent = info.into + ' / ' + info.need + ' XP'; });
    $('#hud-level').textContent = 'Lv ' + info.level;
    $('#hud-xp').style.width = pct;
  }
  function addXp(n) {
    if (n <= 0) return;
    const before = levelInfo(settings.xp).level;
    settings.xp += n;
    if (G) G.xpEarned += n;
    const after = levelInfo(settings.xp).level;
    if (after > before) {
      let coins = 0;
      for (let l = before + 1; l <= after; l++) coins += levelReward(l);
      addCoins(coins);
      settings.tickets += after - before;      // a spin ticket for every level
      let gold = 0; for (let l = before + 1; l <= after; l++) if (l % 10 === 0) gold++;
      settings.gold += gold;                   // a gold ticket every 10 levels
      renderCoins();
      showLevelUp(after, coins, gold);
    }
    addPassXp(n); renderPass(); renderLevel(); saveSoon();
  }
  function showLevelUp(level, coins, gold) {
    const b = $('#levelup');
    b.innerHTML = '<strong>Level ' + level + '!</strong><small>+' + coins + ' coins and a spin ticket' + (gold ? ' + ' + gold + ' gold ticket' : '') + '</small>';
    confetti(40); try { if (navigator.vibrate) navigator.vibrate([40, 60, 40, 60, 120]); } catch (e) { /* no haptics */ }
    b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
    play('powerup', .8);
  }

  /* ---------- Game Pass ---------- */
  // 1 gold ticket per 10 player levels. 10 gold tickets buy the pass. Pass XP = the XP you earn while slicing.
  const PASS_COST = 10, PASS_MAX = 100, PASS_WEAPON = 'royal-gold-blade';
  const passNeed = l => 80 + 4 * (l - 1);              // XP to finish pass level l
  const passReward = l => ({ coins: 25 + 2 * l + (l % 10 === 0 ? 100 : 0) + (l === PASS_MAX ? 900 : 0), tickets: l % 5 === 0 ? 1 : 0, weapon: l === PASS_MAX, gift: l % 25 === 0 && l < PASS_MAX });
  function passInfo(xp) {
    let done = 0, into = xp;
    while (done < PASS_MAX && into >= passNeed(done + 1)) { into -= passNeed(done + 1); done++; }
    return { done, into, need: done >= PASS_MAX ? 1 : passNeed(done + 1) };
  }
  function passMsg(t, bad) { const e = $('#pass-msg'); e.textContent = t; e.classList.toggle('bad', !!bad); }
  function renderPass() {
    const pi = passInfo(settings.passXp), full = pi.done >= PASS_MAX;
    $$('[data-gold]').forEach(e => { e.textContent = settings.gold; });
    $('#sub-pass').textContent = settings.pass ? 'Level ' + pi.done + ' / ' + PASS_MAX : settings.gold + ' / ' + PASS_COST + ' gold tickets';
    $('#pass-buy').hidden = settings.pass; $('#pass-prog').hidden = !settings.pass;
    $('#pass-buy-btn').disabled = settings.gold < PASS_COST;
    $('#pass-lvl').textContent = full ? 'Complete!' : 'Level ' + (pi.done + 1);
    $('#pass-xp').textContent = full ? '' : pi.into + ' / ' + pi.need + ' XP';
    $('#pass-fill').style.width = (full ? 100 : pi.into / pi.need * 100).toFixed(1) + '%';
  }
  function buildPassList() {
    const box = $('#pass-list'), done = settings.pass ? passInfo(settings.passXp).done : 0; box.innerHTML = '';
    for (let l = 1; l <= PASS_MAX; l++) {
      const r = passReward(l), d = document.createElement('div');
      d.className = 'pass-cell' + (l <= done ? ' done' : settings.pass && l === done + 1 ? ' now' : '') + (r.weapon ? ' big' : '');
      d.innerHTML = '<b>' + l + '</b><span>' + (r.weapon ? 'Royal gold blade' : r.coins + ' coins') + '</span>' +
        (r.weapon ? '<small>+ ' + r.coins + ' coins</small>' : r.gift ? '<small>+ free weapon</small>' : r.tickets ? '<small>+ spin ticket</small>' : '');
      box.appendChild(d);
    }
  }
  function grantPass(upTo) {   // pays every reward up to this pass level, once
    upTo = Math.min(PASS_MAX, upTo);
    if (upTo <= settings.passDone) return;
    let coins = 0, tickets = 0, weapon = false; const gifts = [];
    for (let l = settings.passDone + 1; l <= upTo; l++) {
      const r = passReward(l); coins += r.coins; tickets += r.tickets; weapon = weapon || r.weapon;
      if (r.gift) {   // pass levels 25 / 50 / 75 hand you a random weapon you do not own yet
        const pool = WEAPONS.filter(w => w.price > 0 && !w.passOnly && !isOwned(w.id));
        if (pool.length) { const w = pick(pool); settings.owned.push(w.id); gifts.push(w.name); }
      }
    }
    settings.passDone = upTo; settings.tickets += tickets; addCoins(coins);
    if (weapon && !isOwned(PASS_WEAPON)) settings.owned.push(PASS_WEAPON);
    const b = $('#levelup');
    b.innerHTML = weapon ? '<strong>Pass complete!</strong><small>Royal gold blade unlocked</small>' : '<strong>Pass level ' + upTo + '!</strong><small>+' + coins + ' coins' + (tickets ? ' and a spin ticket' : '') + (gifts.length ? ' + ' + gifts.join(', ') : '') + '</small>';
    if (weapon) confetti(80);
    b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
    play('powerup', .8); renderCoins(); buildWeapons();
  }
  function addPassXp(n) {
    if (!settings.pass || passInfo(settings.passXp).done >= PASS_MAX) return;
    settings.passXp += n;
    grantPass(passInfo(settings.passXp).done);
  }
  function buyPass() {
    if (settings.pass) return;
    if (settings.gold < PASS_COST) { passMsg('You need ' + (PASS_COST - settings.gold) + ' more gold tickets.', true); return; }
    settings.gold -= PASS_COST; settings.pass = true; settings.passXp = 0; settings.passDone = 0;
    save(); play('powerup', 1); confetti(60);
    renderPass(); buildPassList(); passMsg('Game Pass unlocked! Slice fruit to level it up.');
  }

  /* ---------- Leaderboard (saved on this device) ---------- */
  const MAX_PER_DIFFICULTY = 25;
  let lbDiff = settings.difficulty, lastEntryId = null;
  function recordScore(score) {
    if (score <= 0) return null;
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name: settings.name || 'Player', pid: settings.pid, score, diff: settings.difficulty,
      level: levelInfo(settings.xp).level, date: Date.now()
    };
    settings.scores.push(entry);
    settings.scores.sort((a, b) => b.score - a.score || a.date - b.date);
    const seen = {};
    settings.scores = settings.scores.filter(e => (seen[e.diff] = (seen[e.diff] || 0) + 1) <= MAX_PER_DIFFICULTY);
    lastEntryId = entry.id;
    save();
    return entry;
  }
  function rankOf(entry) {
    if (!entry) return 0;
    return settings.scores.filter(e => e.diff === entry.diff).findIndex(e => e.id === entry.id) + 1;
  }
  function buildLeaderboard() {
    $$('[data-lb]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.lb === lbDiff)));
    const body = $('#lb-body'); body.innerHTML = '';
    const rows = settings.scores.filter(e => e.diff === lbDiff).slice(0, 10);
    $('#lb-empty').hidden = rows.length > 0;
    rows.forEach((e, i) => {
      const tr = document.createElement('tr');
      if (e.id === lastEntryId) tr.classList.add('me');
      const cell = (cls, text) => { const td = document.createElement('td'); td.className = cls; td.textContent = text; return td; };
      const rankTd = cell('', ''); const badge = document.createElement('span');
      badge.className = 'rank-badge' + (i < 3 ? ' r' + (i + 1) : ''); badge.textContent = i + 1; rankTd.appendChild(badge);
      tr.appendChild(rankTd);
      tr.appendChild(cell('name', e.name));
      tr.appendChild(cell('score', e.score));
      tr.appendChild(cell('', e.level || 1));
      tr.appendChild(cell('date date-col', new Date(e.date).toLocaleDateString()));
      body.appendChild(tr);
    });
  }
  $$('[data-lb]').forEach(b => b.addEventListener('click', () => { lbDiff = b.dataset.lb; buildLeaderboard(); }));
  $('#btn-lb-clear').addEventListener('click', () => {
    if (!window.confirm('Clear all saved scores on this device?')) return;
    settings.scores = []; lastEntryId = null; save(); buildLeaderboard();
  });

  function cleanName(v) { return (String(v).trim().slice(0, 14)) || 'Player'; }

  /* ---------- Weapons screen (shop) ---------- */
  function setShopMsg(text, bad) {
    const m = $('#shop-msg'); m.textContent = text || ''; m.classList.toggle('bad', !!bad);
  }
  function buildWeapons() {
    const grid = $('#weapon-grid'); grid.innerHTML = '';
    WEAPONS.forEach(w => {
      const owned = isOwned(w.id), equipped = w.id === settings.weapon;
      const b = document.createElement('button');
      b.className = 'weapon-card' + (owned ? '' : ' locked') + (!owned && settings.coins < w.price ? ' cant' : '');
      b.setAttribute('aria-pressed', String(equipped));
      const art = w.frames
        ? `<span class="sprite-box"><span class="sprite${w.pixel ? ' pixel' : ''}" style="--fw:${w.fw}px;--fh:${w.fh}px;--n:${w.frames};--dur:${(w.frames / w.fps).toFixed(2)}s;--s:${w.fw > 64 ? (84 / Math.max(w.fw, w.fh)).toFixed(3) : 1.5};background-image:url('${w.img}')"></span></span>`
        : `<img class="${w.pixel ? 'pixel' : ''}" src="${w.img}" alt="">`;
      const price = owned ? '' : w.passOnly ? '<span class="price">Pass level 100</span>' : `<span class="price"><i class="coin"></i>${w.price}</span>`;
      const label = equipped ? 'Equipped' : owned ? 'Equip' : w.passOnly ? 'Locked' : 'Buy';
      b.innerHTML = `${art}<span class="name">${w.name}</span><span class="desc">${w.desc}</span><span class="ability">${abilityLine(w.id)}</span>${price}<span class="tag">${label}</span>`;
      b.addEventListener('click', () => onWeaponClick(w));
      grid.appendChild(b);
    });
    renderCoins();
  }
  let noCoinsAudio = null;
  function onWeaponClick(w) {
    const idx = WEAPONS.indexOf(w);
    if (isOwned(w.id)) {
      settings.weapon = w.id; save(); play('slice', .6, 1.2);
      setShopMsg(w.name + ' equipped.');
      buildWeapons();
    } else if (w.passOnly) {
      setShopMsg('Finish Game Pass level 100 to unlock ' + w.name + '.', true);
    } else if (settings.coins >= w.price) {
      settings.coins -= w.price; settings.owned.push(w.id); settings.weapon = w.id; save();
      play('powerup', .8);
      setShopMsg('You bought ' + w.name + ' and equipped it.');
      buildWeapons();
    } else {
      setShopMsg('You need ' + (w.price - settings.coins) + ' more coins for the ' + w.name + '.', true);
      if (noCoinsAudio) { try { noCoinsAudio.pause(); } catch (e) {} }   // restart instead of overlapping on repeat taps
      noCoinsAudio = play('nocoins', .9);
      buildWeapons();
      const card = $('#weapon-grid').children[idx]; if (card) card.classList.add('shake');
    }
  }

  /* =====================================================
     Lucky spin
  ===================================================== */
  const SPIN_COST = 150;          // coins for an extra spin
  const FREE_SPIN_HOURS = 24;     // one free spin every 24 hours
  // weight = chance out of 100. Order = order around the wheel (clockwise from the top).
  const SEGMENTS = [
    { label: '25',     sub: 'coins',   type: 'coins',  amt: 25,   weight: 30, color: '#2f9a46' },
    { label: 'XP',     sub: '+150',    type: 'xp',     amt: 150,  weight: 14, color: '#6c4ad8' },
    { label: '50',     sub: 'coins',   type: 'coins',  amt: 50,   weight: 25, color: '#e8383d' },
    { label: '250',    sub: 'coins',   type: 'coins',  amt: 250,  weight: 8,  color: '#ff9f1a' },
    { label: '100',    sub: 'coins',   type: 'coins',  amt: 100,  weight: 15, color: '#2f9a46' },
    { label: 'Weapon', sub: 'random',  type: 'weapon', amt: 0,    weight: 4,  color: '#2b6fd6' },
    { label: '500',    sub: 'coins',   type: 'coins',  amt: 500,  weight: 3,  color: '#e8383d' },
    { label: '1000',   sub: 'JACKPOT', type: 'coins',  amt: 1000, weight: 1,  color: '#ffcf3d', dark: true }
  ];
  const wheel = $('#wheel'), wctx = wheel.getContext('2d');
  let wheelRot = 0, spinning = false;

  const freeLeftMs = () => Math.max(0, FREE_SPIN_HOURS * 3600e3 - (Date.now() - settings.lastFree));
  const freeReady = () => freeLeftMs() === 0;
  const fmtTime = ms => {
    const t = Math.ceil(ms / 1000), h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), x = t % 60;
    return h + ':' + String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0');
  };

  function drawWheel(time = 0) {
    const c = wctx, N = SEGMENTS.length, seg = Math.PI * 2 / N;
    const W = wheel.width, cx = W / 2, R = W / 2 - 22;
    c.clearRect(0, 0, W, W);
    c.save(); c.translate(cx, cx);
    // outer rim
    c.beginPath(); c.arc(0, 0, R + 18, 0, 6.283); c.fillStyle = '#17112a'; c.fill();
    c.beginPath(); c.arc(0, 0, R + 18, 0, 6.283); c.lineWidth = 5; c.strokeStyle = '#fff4dc'; c.stroke();
    c.rotate(wheelRot);
    SEGMENTS.forEach((sg, i) => {
      const a0 = i * seg - seg / 2 - Math.PI / 2;
      c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, R, a0, a0 + seg); c.closePath();
      c.fillStyle = sg.color; c.fill();
      c.lineWidth = 4; c.strokeStyle = '#17112a'; c.stroke();
      c.save(); c.rotate(i * seg);
      c.textAlign = 'center'; c.fillStyle = sg.dark ? '#17112a' : '#fff4dc';
      const fs = sg.label.length >= 6 ? 34 : sg.label.length >= 4 ? 44 : 56;
      c.font = `${fs}px "Titan One", Impact, sans-serif`;
      c.lineJoin = 'round';
      if (!sg.dark) { c.lineWidth = 8; c.strokeStyle = 'rgba(23,17,42,.55)'; c.strokeText(sg.label, 0, -R * .6); }
      c.fillText(sg.label, 0, -R * .6);
      c.font = '700 22px "Baloo 2", system-ui, sans-serif';
      c.fillText(sg.sub, 0, -R * .6 + 28);
      c.restore();
    });
    c.restore();
    // blinking lights (they stay still while the wheel turns)
    c.save(); c.translate(cx, cx);
    for (let i = 0; i < 20; i++) {
      const a = i / 20 * 6.283, lit = spinning ? (i + Math.floor(time * 9)) % 2 === 0 : i % 2 === 0;
      c.beginPath(); c.arc(Math.cos(a) * (R + 9), Math.sin(a) * (R + 9), 5.5, 0, 6.283);
      c.fillStyle = lit ? '#fff3a8' : '#a07a1a'; c.fill();
    }
    // hub
    const g = c.createRadialGradient(-10, -12, 6, 0, 0, 52);
    g.addColorStop(0, '#fff3a8'); g.addColorStop(1, '#e19a0a');
    c.beginPath(); c.arc(0, 0, 50, 0, 6.283); c.fillStyle = g; c.fill();
    c.lineWidth = 6; c.strokeStyle = '#17112a'; c.stroke();
    c.restore();
  }
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => drawWheel());

  function weightedIndex() {
    let r = Math.random() * SEGMENTS.reduce((a, x) => a + x.weight, 0);
    for (let i = 0; i < SEGMENTS.length; i++) { r -= SEGMENTS[i].weight; if (r < 0) return i; }
    return 0;
  }

  function spinTo(idx, done) {
    const seg = Math.PI * 2 / SEGMENTS.length, TAU = Math.PI * 2;
    const target = -(idx * seg + rand(-0.38, 0.38) * seg);               // wheel angle that puts this slice under the pointer
    const base = wheelRot;
    const delta = (((target - base) % TAU) + TAU) % TAU;
    const total = delta + TAU * (5 + Math.floor(rand(0, 2)));
    const dur = 5200, start = performance.now();
    let lastSlice = null, lastTick = 0;
    (function frame(now) {
      const t = clamp((now - start) / dur, 0, 1), e = 1 - Math.pow(1 - t, 4);
      wheelRot = base + total * e;
      const slice = Math.round(-wheelRot / seg);
      if (slice !== lastSlice) { lastSlice = slice; if (now - lastTick > 55) { play('slice', .22, 1.5 + rand(0, .3)); lastTick = now; } }
      drawWheel(now / 1000);
      if (t < 1) requestAnimationFrame(frame); else done();
    })(start);
  }

  function claimPrize() {
    const seg = SEGMENTS[settings.pending];
    if (!seg) { settings.pending = null; return null; }
    settings.pending = null;
    let text;
    if (seg.type === 'coins') { addCoins(seg.amt); text = seg.amt + ' coins'; }
    else if (seg.type === 'xp') { addXp(seg.amt); text = seg.amt + ' XP'; }
    else {
      const pool = WEAPONS.filter(w => w.price > 0 && !w.passOnly && !isOwned(w.id));
      if (pool.length) { const w = pick(pool); settings.owned.push(w.id); text = w.name; }
      else { addCoins(400); text = '400 coins (you own every weapon)'; }
    }
    save(); renderCoins(); renderLevel();
    return { seg, text };
  }

  function beginSpin(mode) {
    if (spinning) return;
    if (mode === 'free')        { if (!freeReady()) return; settings.lastFree = Date.now(); }
    else if (mode === 'ticket') { if (settings.tickets < 1) return; settings.tickets--; }
    else                        { if (settings.coins < SPIN_COST) return; settings.coins -= SPIN_COST; }
    const idx = weightedIndex();
    settings.pending = idx; save();           // decided and saved first, so a refresh can't dodge the result
    renderCoins();
    spinning = true; $('#spin-win').classList.remove('show');
    renderSpinUI();
    spinTo(idx, () => {
      spinning = false; drawWheel();
      const res = claimPrize();
      renderSpinUI();
      if (res) showWin(res);
    });
  }

  function showWin(res) {
    const jackpot = res.seg.sub === 'JACKPOT';
    $('#win-title').textContent = jackpot ? 'JACKPOT!' : 'You won';
    $('#win-prize').textContent = res.text;
    $('#win-sub').textContent = res.seg.type === 'weapon' && !res.text.includes('coins') ? 'Find it in Weapons.' : '';
    $('#spin-win').classList.add('show');
    play('powerup', 1);
    confetti(jackpot ? 140 : 55);
  }
  function confetti(n) {
    if (REDUCED) return;
    const box = $('#confetti'), colors = ['#ff5a4d', '#ffc23a', '#7bd88f', '#6c9aff', '#ff86dc', '#fff4dc'];
    for (let i = 0; i < n; i++) {
      const p = document.createElement('i');
      p.style.left = rand(0, 100) + '%';
      p.style.background = pick(colors);
      p.style.setProperty('--x', rand(-120, 120) + 'px');
      p.style.setProperty('--r', rand(360, 1080) + 'deg');
      p.style.setProperty('--d', rand(1.8, 3.2) + 's');
      p.style.setProperty('--delay', rand(0, .5) + 's');
      box.appendChild(p);
      setTimeout(() => p.remove(), 4000);
    }
  }

  function renderSpinUI() {
    const ready = freeReady(), t = settings.tickets;
    $('#spin-card-status').textContent = ready ? 'Free spin ready!' : t > 0 ? t + ' spin ticket' + (t > 1 ? 's' : '') : 'Next free spin in ' + fmtTime(freeLeftMs());
    const badge = $('#spin-badge'); badge.hidden = !(ready || t > 0); badge.textContent = ready ? 'Free' : 'Ticket';
    const primary = $('#btn-spin'), label = primary.querySelector('span');
    if (ready)      { label.textContent = 'Free spin'; primary.disabled = spinning; }
    else if (t > 0) { label.textContent = 'Use a ticket (' + t + ')'; primary.disabled = spinning; }
    else            { label.textContent = 'Free spin in ' + fmtTime(freeLeftMs()); primary.disabled = true; }
    const coinsBtn = $('#btn-spin-coins');
    coinsBtn.querySelector('span').textContent = 'Spin for ' + SPIN_COST + ' coins';
    coinsBtn.disabled = spinning || settings.coins < SPIN_COST;
    $$('#screen-spin [data-back]').forEach(b => { b.disabled = spinning; });
    $('#spin-status').textContent = spinning ? 'Good luck...' : ready ? 'Your free spin is ready.' : t > 0 ? 'You have a spin ticket to use.' : 'Come back for your next free spin, or spin with coins.';
  }
  setInterval(renderSpinUI, 1000);

  $('#btn-spin').addEventListener('click', () => beginSpin(freeReady() ? 'free' : 'ticket'));
  $('#btn-spin-coins').addEventListener('click', () => beginSpin('coins'));
  $('#btn-win-ok').addEventListener('click', () => $('#spin-win').classList.remove('show'));
  (function buildPrizeList() {
    const list = $('#prize-list'), total = SEGMENTS.reduce((a, x) => a + x.weight, 0);
    SEGMENTS.forEach(sg => {
      const li = document.createElement('li');
      li.innerHTML = '<span class="sw"></span><span class="pn"></span><em></em>';
      li.querySelector('.sw').style.background = sg.color;
      li.querySelector('.pn').textContent = sg.type === 'coins' ? sg.amt + ' coins' : sg.type === 'xp' ? sg.amt + ' XP' : 'Weapon';
      li.querySelector('em').textContent = Math.round(sg.weight / total * 100) + '%';
      list.appendChild(li);
    });
  })();
  // a spin that was interrupted by closing the page: hand out the prize now
  function recoverPending() {
    const res = claimPrize();
    if (res) setTimeout(() => {
      const b = $('#levelup'); b.textContent = 'Spin prize collected: ' + res.text;
      b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
    }, 600);
  }

  /* ---------- Settings screen ---------- */
  function syncSettingsUI() {
    $('#set-name').value = settings.name === 'Player' ? '' : settings.name;
    $('#set-sound').checked = settings.sound;
    { const pe = $('#set-pid'); if (pe) pe.textContent = settings.pid; }
    $('#set-volume').value = Math.round(settings.volume * 100);
    $('#set-music').checked = settings.music;
    $('#set-music-volume').value = Math.round(settings.musicVolume * 100);
    $('#set-track').value = settings.track;
    $('#set-trail').checked = settings.trail;
    $('#set-size').value = Math.round(settings.weaponSize * 100);
    ZT = settings.zoom; if (!G || G.over) setView(ZT); renderZoomUI();
    $('#set-bg').value = String(settings.bgSeconds);
    $$('[data-diff]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.diff === settings.difficulty)));
  }
  $('#set-name').addEventListener('input', e => { settings.name = cleanName(e.target.value); saveSoon(); });
  $('#set-sound').addEventListener('change', e => { settings.sound = e.target.checked; save(); });
  $('#set-volume').addEventListener('input', e => { settings.volume = e.target.value / 100; save(); });
  $('#set-volume').addEventListener('change', () => play('slice', .8));
  $('#set-track').innerHTML = [{ id: 'shuffle', name: 'Shuffle all tracks' }].concat(MUSIC_TRACKS).map(t => '<option value="' + t.id + '">' + t.name + '</option>').join('');
  $('#set-music').addEventListener('change', e => { settings.music = e.target.checked; save(); applyMusic(); });
  $('#set-music-volume').addEventListener('input', e => { settings.musicVolume = e.target.value / 100; saveSoon(); applyMusic(); });
  $('#set-track').addEventListener('change', e => {
    settings.track = e.target.value; settings.music = true; $('#set-music').checked = true;
    save(); bgmUnlocked = true; applyMusic();   // plays right away so the player hears the new track
  });
  $('#set-trail').addEventListener('change', e => { settings.trail = e.target.checked; save(); });
  $('#set-size').addEventListener('input', e => { settings.weaponSize = e.target.value / 100; save(); });
  $('#set-bg').addEventListener('change', e => { settings.bgSeconds = +e.target.value; save(); });
  $$('[data-diff]').forEach(b => b.addEventListener('click', () => { settings.difficulty = b.dataset.diff; save(); syncSettingsUI(); }));

  /* ---------- Menu buttons ---------- */
  $('#btn-play').addEventListener('click', startGame);
  $('#btn-weapons').addEventListener('click', () => { setShopMsg(''); buildWeapons(); setScreen('weapons'); });
  $('#btn-spin-open').addEventListener('click', () => { drawWheel(); renderSpinUI(); setScreen('spin'); });
  $('#btn-pass').addEventListener('click', () => { passMsg(''); renderPass(); buildPassList(); setScreen('pass'); const n = $('#pass-list .now'); if (n) n.scrollIntoView({ block: 'nearest' }); });
  $('#pass-buy-btn').addEventListener('click', buyPass);
  $('#btn-leaderboard').addEventListener('click', () => { lbDiff = settings.difficulty; buildLeaderboard(); setScreen('leaderboard'); });
  $('#btn-settings').addEventListener('click', () => { syncSettingsUI(); setScreen('settings'); });
  $$('[data-back]').forEach(b => b.addEventListener('click', () => enterMenu('menu')));

  $('#btn-pause').addEventListener('click', pauseGame);
  $('#btn-resume').addEventListener('click', resumeGame);
  $('#btn-pause-quit').addEventListener('click', quitToMenu);
  $('#btn-again').addEventListener('click', startGame);
  $('#over-name').addEventListener('input', e => {
    settings.name = cleanName(e.target.value);
    if (G && G.entry) G.entry.name = settings.name;   // same object that is stored in the leaderboard
    saveSoon();
  });
  $('#btn-over-weapons').addEventListener('click', () => { quitToMenu(); setShopMsg(''); buildWeapons(); setScreen('weapons'); });
  $('#btn-over-menu').addEventListener('click', quitToMenu);

  window.addEventListener('keydown', e => {
    if (e.target && e.target.tagName === 'INPUT') return;   // typing a name
    if (e.key === 'Escape' || e.key.toLowerCase() === 'p') {
      if (!G || G.over) return;
      G.paused ? resumeGame() : pauseGame();
    }
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseGame(); });

  /* =====================================================
     Live menu scene: fruit floats up behind the menu.
     A ghost blade slices some of it, and so can you.
  ===================================================== */
  const fx = $('#menu-fx'), fctx = fx.getContext('2d');
  let FW = 1, FH = 1, FS = 1;
  function fxResize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    FW = window.innerWidth; FH = window.innerHeight;
    fx.width = Math.round(FW * dpr); fx.height = Math.round(FH * dpr);
    fctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    FS = clamp(Math.min(FW, FH * 1.25) / 900, 0.55, 1.3);
  }
  // floating particles that match each arena (same order as BACKGROUNDS)
  const THEMES = [
    { kind: 'pollen', color: '#ffe9a0' }, { kind: 'snow',  color: '#ffffff' }, { kind: 'rain',  color: '#7df3ff' },
    { kind: 'ember',  color: '#ff8a1a' }, { kind: 'petal', color: '#ffb3d9' }, { kind: 'ember', color: '#ff5a2a' },
    { kind: 'pollen', color: '#e6ff9a' }, { kind: 'pollen', color: '#fff7b0' }, { kind: 'petal', color: '#ffe0f0' },
    { kind: 'ember',  color: '#ff9a3a' }, { kind: 'pollen', color: '#c8ff8a' }
  ];
  const M = {
    on: false, id: 0, last: 0, t: 0, bgTimer: 0, spawn: 0.3, ghost: 2.2,
    fruits: [], halves: [], parts: [], amb: [], trail: [], ghostTrail: [],
    mx: 0, my: 0, inside: false, px: 0, py: 0, ptx: 0, pty: 0
  };
  const menuActive = () => $('#screen-menu').classList.contains('active');

  function seedAmbient() {
    const kind = THEMES[menuBgIndex % THEMES.length].kind;
    M.amb = [];
    for (let i = 0; i < 46; i++) {
      M.amb.push({
        x: rand(0, FW), y: rand(0, FH), ph: rand(0, 6.28), sz: rand(1.5, 4.5) * FS,
        vx: kind === 'petal' ? rand(15, 45) : kind === 'rain' ? rand(-30, -10) : rand(-12, 12),
        vy: kind === 'ember' ? -rand(25, 90) : kind === 'snow' ? rand(25, 60) : kind === 'petal' ? rand(30, 60) : kind === 'rain' ? rand(380, 620) : rand(-8, 8)
      });
    }
  }

  function menuLaunch() {
    if (M.fruits.length >= 7) return;
    const type = pick(FRUIT_POOL), size = rand(84, 128) * FS;
    const x = rand(FW * 0.05, FW * 0.95), g = FH * 1.05, h = FH * rand(0.5, 0.85);
    const vy = -Math.sqrt(2 * g * h), flight = 2 * Math.sqrt(2 * h / g);
    M.fruits.push({
      type, img: fruitImg[type], pixel: FRUITS[type].pixel, size, r: size * 0.5,
      x, y: FH + size * 0.6, vx: (FW / 2 - x) / flight * rand(0.15, 0.6), vy, g,
      rot: rand(0, 6.28), vr: rand(-2.5, 2.5)
    });
  }

  function menuSlice(f, ang, byUser) {
    M.fruits.splice(M.fruits.indexOf(f), 1);
    const base = ang - Math.PI / 2;
    [-1, 1].forEach(side => {
      const sep = rand(100, 200) * FS;
      M.halves.push({
        x: f.x, y: f.y, size: f.size, img: f.img, pixel: f.pixel, g: f.g,
        vx: f.vx * 0.6 + Math.cos(base) * side * sep, vy: f.vy * 0.4 - rand(30, 110) * FS + Math.sin(base) * side * sep,
        rot: 0, vr: side * rand(1.5, 4), fruitRot: f.rot, base, side
      });
    });
    const colors = FRUITS[f.type].juice;
    for (let i = 0; i < 14; i++) {
      const a = rand(0, 6.28), sp = rand(100, 380) * FS;
      M.parts.push({ x: f.x, y: f.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60 * FS, life: rand(.4, .85), max: .85, size: rand(3, 6) * FS, color: pick(colors) });
    }
    if (byUser) play('slice', .45, rand(0.92, 1.12));
  }

  function ghostSlice() {
    const list = M.fruits.filter(f => f.y > FH * 0.15 && f.y < FH * 0.85);
    if (!list.length) return;
    const f = pick(list);
    const ang = rand(-0.5, 0.5) + (Math.random() < 0.5 ? 0 : Math.PI) + rand(-0.6, 0.6);
    const dx = Math.cos(ang), dy = Math.sin(ang), now = performance.now();
    M.ghostTrail = [];
    for (let k = 0; k <= 9; k++) {
      const d = (k / 9 - 0.5) * f.r * 5;
      M.ghostTrail.push({ x: f.x + dx * d, y: f.y + dy * d, t: now - (9 - k) * 10 });
    }
    menuSlice(f, ang, false);
  }

  function menuSegment(x1, y1, x2, y2) {
    if (Math.hypot(x2 - x1, y2 - y1) < 3) return;
    const ang = Math.atan2(y2 - y1, x2 - x1);
    for (let i = M.fruits.length - 1; i >= 0; i--) {
      const f = M.fruits[i];
      if (distToSegment(f.x, f.y, x1, y1, x2, y2) <= f.r) menuSlice(f, ang, true);
    }
  }
  document.addEventListener('pointermove', e => {
    if (!M.on) return;
    M.ptx = -(e.clientX / FW - 0.5) * 18; M.pty = -(e.clientY / FH - 0.5) * 12;   // background parallax
    if (!menuActive()) return;
    if (e.pointerType !== 'mouse' && e.buttons === 0 && e.pressure === 0) return;
    if (M.inside) menuSegment(M.mx, M.my, e.clientX, e.clientY);
    M.mx = e.clientX; M.my = e.clientY; M.inside = true;
    M.trail.push({ x: e.clientX, y: e.clientY, t: performance.now() });
    if (M.trail.length > 40) M.trail.shift();
  });
  document.addEventListener('pointerdown', e => {
    if (!M.on || !menuActive() || (e.target.closest && e.target.closest('button, input, select'))) return;
    M.inside = false;
    for (let i = M.fruits.length - 1; i >= 0; i--) {          // tap a fruit to slice it
      const f = M.fruits[i];
      if (Math.hypot(f.x - e.clientX, f.y - e.clientY) <= f.r) menuSlice(f, rand(-0.8, 0.8), true);
    }
  });
  document.addEventListener('pointerup', () => { M.inside = false; });

  function menuNextBg() {
    menuBgIndex = (menuBgIndex + 1) % BACKGROUNDS.length;
    setBackground(menuBgIndex);
    $('#menu-arena').textContent = BACKGROUNDS[menuBgIndex].name;
    seedAmbient();
  }

  function fxTrail(list, life) {
    const now = performance.now(), w = weaponDef();
    while (list.length && now - list[0].t > life) list.shift();
    if (list.length < 2) return;
    fctx.lineCap = 'round'; fctx.lineJoin = 'round';
    [{ c: w.glow, w: 16, a: .6, blur: 18 }, { c: w.trail, w: 6, a: 1, blur: 0 }].forEach(p => {
      fctx.shadowColor = w.glow; fctx.shadowBlur = p.blur; fctx.strokeStyle = p.c;
      for (let i = 1; i < list.length; i++) {
        const age = clamp(1 - (now - list[i].t) / life, 0, 1);
        fctx.globalAlpha = age * p.a; fctx.lineWidth = Math.max(1, p.w * FS * age);
        fctx.beginPath(); fctx.moveTo(list[i - 1].x, list[i - 1].y); fctx.lineTo(list[i].x, list[i].y); fctx.stroke();
      }
    });
    fctx.globalAlpha = 1; fctx.shadowBlur = 0;
  }

  function menuLoop(now) {
    if (!M.on) return;
    const dt = Math.min(0.05, (now - M.last) / 1000); M.last = now; M.t += dt;

    M.bgTimer += dt; if (M.bgTimer >= 25) { M.bgTimer = 0; menuNextBg(); }
    M.px += (M.ptx - M.px) * Math.min(1, dt * 4); M.py += (M.pty - M.py) * Math.min(1, dt * 4);
    const rs = document.documentElement.style;
    rs.setProperty('--px', M.px.toFixed(1) + 'px'); rs.setProperty('--py', M.py.toFixed(1) + 'px');

    M.spawn -= dt; if (M.spawn <= 0) { menuLaunch(); M.spawn = rand(0.7, 1.5); }
    M.ghost -= dt; if (M.ghost <= 0) { ghostSlice(); M.ghost = rand(2.5, 4.5); }

    for (let i = M.fruits.length - 1; i >= 0; i--) {
      const f = M.fruits[i]; f.vy += f.g * dt; f.x += f.vx * dt; f.y += f.vy * dt; f.rot += f.vr * dt;
      if (f.y > FH + f.size && f.vy > 0) M.fruits.splice(i, 1);
    }
    for (let i = M.halves.length - 1; i >= 0; i--) {
      const h = M.halves[i]; h.vy += h.g * dt; h.x += h.vx * dt; h.y += h.vy * dt; h.rot += h.vr * dt;
      if (h.y > FH + h.size * 2) M.halves.splice(i, 1);
    }
    for (let i = M.parts.length - 1; i >= 0; i--) {
      const p = M.parts[i]; p.vy += FH * 0.5 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
      if (p.life <= 0) M.parts.splice(i, 1);
    }
    const kind = THEMES[menuBgIndex % THEMES.length].kind, tc = THEMES[menuBgIndex % THEMES.length].color;
    M.amb.forEach(a => {
      a.ph += dt;
      a.x += (a.vx + Math.sin(a.ph * 1.3) * (kind === 'rain' ? 0 : 14)) * dt; a.y += a.vy * dt;
      if (a.y > FH + 20) { a.y = -20; a.x = rand(0, FW); }
      if (a.y < -20) { a.y = FH + 20; a.x = rand(0, FW); }
      if (a.x > FW + 20) a.x = -20; if (a.x < -20) a.x = FW + 20;
    });

    // ---- draw ----
    fctx.clearRect(0, 0, FW, FH);
    fctx.fillStyle = tc; fctx.strokeStyle = tc;
    M.amb.forEach(a => {
      fctx.globalAlpha = kind === 'ember' || kind === 'pollen' ? 0.35 + 0.35 * Math.sin(a.ph * 2.2) : 0.7;
      if (kind === 'rain') { fctx.lineWidth = 1.5; fctx.beginPath(); fctx.moveTo(a.x, a.y); fctx.lineTo(a.x + a.vx * 0.04, a.y - 16 * FS); fctx.stroke(); }
      else if (kind === 'petal') { fctx.save(); fctx.translate(a.x, a.y); fctx.rotate(a.ph); fctx.beginPath(); fctx.ellipse(0, 0, a.sz * 1.8, a.sz, 0, 0, 6.283); fctx.fill(); fctx.restore(); }
      else { fctx.beginPath(); fctx.arc(a.x, a.y, a.sz, 0, 6.283); fctx.fill(); }
    });
    fctx.globalAlpha = 1;

    M.halves.forEach(h => {
      fctx.save(); fctx.translate(h.x, h.y); fctx.rotate(h.rot); fctx.rotate(h.base);
      fctx.beginPath(); const s2 = h.size;
      if (h.side < 0) fctx.rect(-s2, -s2, s2, 2 * s2); else fctx.rect(0, -s2, s2, 2 * s2);
      fctx.clip(); fctx.rotate(-h.base); fctx.rotate(h.fruitRot);
      fctx.imageSmoothingEnabled = !h.pixel; fctx.drawImage(h.img, -s2 / 2, -s2 / 2, s2, s2);
      fctx.restore();
    });
    M.fruits.forEach(f => {
      fctx.save(); fctx.translate(f.x, f.y); fctx.rotate(f.rot);
      fctx.imageSmoothingEnabled = !f.pixel; fctx.drawImage(f.img, -f.size / 2, -f.size / 2, f.size, f.size);
      fctx.restore();
    });
    M.parts.forEach(p => {
      fctx.globalAlpha = clamp(p.life / p.max, 0, 1); fctx.fillStyle = p.color;
      fctx.beginPath(); fctx.arc(p.x, p.y, p.size, 0, 6.283); fctx.fill();
    });
    fctx.globalAlpha = 1;
    fxTrail(M.ghostTrail, 260);
    if (settings.trail) fxTrail(M.trail, 220);

    M.id = requestAnimationFrame(menuLoop);
  }
  function menuStart() {
    if (REDUCED || M.on) return;
    M.on = true; M.last = performance.now(); M.bgTimer = 0;
    if (!M.amb.length) seedAmbient();
    M.id = requestAnimationFrame(menuLoop);
  }
  function menuStop() {
    M.on = false; cancelAnimationFrame(M.id);
    M.fruits.length = 0; M.halves.length = 0; M.parts.length = 0; M.trail.length = 0; M.ghostTrail.length = 0; M.amb = [];
    fctx.clearRect(0, 0, FW, FH);
  }

  /* =====================================================
     Canvas
  ===================================================== */
  const canvas = $('#game');
  const ctx = canvas.getContext('2d');
  /* Zoom: the game world is (screen size / Z) units wide. Z > 1 zooms in (a smaller arena,
     bigger fruit); Z < 1 zooms out (a bigger arena, smaller fruit). SW/SH = screen size in CSS px,
     W/H = world size. Fruit size (S) stays constant in world units, so on screen it scales with Z. */
  let W = 0, H = 0, SW = 0, SH = 0, DPR = 1, S = 1;
  let Z = settings.zoom, ZT = Z;   // current zoom (eases) and target zoom
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    SW = window.innerWidth; SH = window.innerHeight;
    W = SW / Z; H = SH / Z;
    canvas.width = Math.round(SW * DPR); canvas.height = Math.round(SH * DPR);
    ctx.setTransform(DPR * Z, 0, 0, DPR * Z, 0, 0);
    const phone = !!(window.matchMedia && matchMedia('(pointer: coarse)').matches) && Math.min(SW, SH) < 700;
    S = clamp(Math.min(SW, SH * 1.25) / 900, 0.55, 1.3) * (phone ? 1.3 : 1); // overall object scale (bigger fruit on phones)
    fxResize();
  }
  window.addEventListener('resize', resize);
  resize();

  /* =====================================================
     Zoom system
  ===================================================== */
  const zoomLabel = $('#zoom-label');
  function setView(z) {   // apply a zoom level now; keeps everything where it is on screen
    const k = Z / z;
    Z = z; W = SW / Z; H = SH / Z;
    ctx.setTransform(DPR * Z, 0, 0, DPR * Z, 0, 0);
    if (G && k !== 1 && isFinite(k)) rescaleWorld(k);
  }
  function rescaleWorld(k) {   // world units changed by k: move positions and speeds (sizes stay)
    const P = o => { o.x *= k; o.y *= k; }, V = o => { o.vx *= k; o.vy *= k; };
    G.fruits.forEach(o => { P(o); V(o); });
    G.halves.forEach(o => { P(o); V(o); });
    G.particles.forEach(o => { P(o); V(o); });
    [G.splats, G.rings, G.popups, G.slashes].forEach(l => l.forEach(P));
    G.coinFx.forEach(c => { c.x0 *= k; c.y0 *= k; c.tx *= k; c.ty *= k; });
    pointer.trail.forEach(P);
    if (pointer.inside) P(pointer);
  }
  function renderZoomUI() {
    const pct = Math.round(ZT * 100);
    if (zoomLabel) zoomLabel.textContent = pct + '%';
    const out = $('#zoom-out'), inn = $('#zoom-in');
    if (out) out.disabled = ZT <= ZOOM_MIN + 0.001;
    if (inn) inn.disabled = ZT >= ZOOM_MAX - 0.001;
    const sl = $('#set-zoom'); if (sl) sl.value = pct;
    const sv = $('#set-zoom-val'); if (sv) sv.textContent = pct + '%';
  }
  function setZoom(z, instant) {
    ZT = clamp(Math.round(z * 100) / 100, ZOOM_MIN, ZOOM_MAX);
    settings.zoom = ZT; saveSoon();
    if (instant || !G || G.over) setView(ZT);   // otherwise the game loop eases toward ZT
    renderZoomUI();
  }
  const zoomBy = d => setZoom(ZT + d);
  function easeZoom(dt) {
    if (Z === ZT) return;
    if (REDUCED || Math.abs(ZT - Z) < 0.002) setView(ZT);
    else setView(Z + (ZT - Z) * Math.min(1, dt * 12));
  }
  // (null-safe: an older cached index.html without the zoom buttons must not break the game)
  const on = (sel, ev, fn) => { const el = $(sel); if (el) el.addEventListener(ev, fn); };
  on('#zoom-in', 'click', () => zoomBy(ZOOM_STEP));
  on('#zoom-out', 'click', () => zoomBy(-ZOOM_STEP));
  on('#zoom-label', 'click', () => setZoom(1));   // tap the percentage to reset
  on('#set-zoom', 'input', e => setZoom(e.target.value / 100, true));
  on('#set-zoom', 'change', save);
  canvas.addEventListener('wheel', e => {   // mouse wheel / trackpad pinch
    if (!G || G.over) return;
    e.preventDefault();
    const dy = clamp(e.deltaMode === 1 ? e.deltaY * 33 : e.deltaY, -120, 120);
    setZoom(ZT * Math.exp(-dy * (e.ctrlKey ? 0.01 : 0.0012)));
  }, { passive: false });
  window.addEventListener('keydown', e => {   // + / - / 0
    if (!G || G.over || (e.target && e.target.tagName === 'INPUT') || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '+' || e.key === '=') zoomBy(ZOOM_STEP);
    else if (e.key === '-' || e.key === '_') zoomBy(-ZOOM_STEP);
    else if (e.key === '0') setZoom(1);
  });
  renderZoomUI();

  /* =====================================================
     Game state
  ===================================================== */
  let G = null;
  let loopId = 0, lastT = 0;
  let livesImgs = [];

  function startGame() {
    if (settings.banned) { const b = $('#banner'); if (b) { b.textContent = 'This player ID is banned'; b.classList.remove('go'); void b.offsetWidth; b.classList.add('go'); } return; }
    menuStop();
    stopRage();
    const d = DIFFICULTY[settings.difficulty];
    G = {
      paused: false, over: false, overTimer: 0, overShown: false,
      score: 0, maxLives: d.lives, lives: d.lives,
      time: 0, bgIndex: 0, bgTimer: 0, spawnTimer: 0.7,
      fruits: [], pending: [], halves: [], particles: [], splats: [], rings: [], popups: [], coinFx: [], coinsEarned: 0, xpEarned: 0, entry: null,
      frenzy: 0, shake: 0, flash: 0, flashColor: '#fff',
      swipeHits: 0, swipeTimer: 0, lastSec: -1,
      combo: 0, comboT: 0, bestCombo: 0, shownCombo: -1, ice: 0, slow: 0, hit: 0, slashes: [], volleyT: 24, abN: 0, shield: 1, defuse: 3
    };
    pointer.trail.length = 0; touches.clear(); pinch = null; pinchLock = false;
    ZT = settings.zoom; setView(ZT); renderZoomUI();
    body.classList.remove('in-menu'); body.classList.add('playing');
    setScreen(null);
    hud.hidden = false;
    $('#frenzy').hidden = true; $('#combo').hidden = true;
    setBackground(0);
    $('#arena-name').textContent = BACKGROUNDS[0].name;
    buildLives();
    $('#hud-score').textContent = '0';
    $('#hud-best').textContent = settings.best;
    renderCoins(); renderLevel();
    updateArenaHud();
    keepAwake(true);
    if (ABILITY[settings.weapon]) popup(W / 2, H * 0.3, ABILITY[settings.weapon][0], '#ffd84a');
    cancelAnimationFrame(loopId);
    lastT = performance.now();
    loopId = requestAnimationFrame(loop);
  }

  function buildLives() {
    const box = $('#hud-lives'); box.innerHTML = ''; livesImgs = [];
    for (let i = 0; i < G.maxLives; i++) {
      const im = document.createElement('img'); im.src = FRUITS.apple.src; im.alt = '';
      box.appendChild(im); livesImgs.push(im);
    }
  }

  function saveBest() { if (G && G.score > settings.best) { settings.best = G.score; save(); } }

  function pauseGame() {
    if (!G || G.over || G.paused) return;
    G.paused = true; pointer.trail.length = 0; setScreen('pause');
  }
  function resumeGame() {
    if (!G || !G.paused) return;
    G.paused = false; setScreen(null); lastT = performance.now();
  }
  function quitToMenu() {
    saveBest(); stopRage(); keepAwake(false);
    cancelAnimationFrame(loopId);
    if (G) menuBgIndex = G.bgIndex;
    G = null;
    $('#banner').classList.remove('go');
    enterMenu('menu');
  }

  function gameOver() {
    G.over = true; G.overTimer = 0; G.lives = 0; $('#combo').hidden = true;
    livesImgs.forEach(im => im.classList.add('lost'));
    saveBest();
    const bonus = Math.floor(G.score / 10);   // end-of-run bonus: 1 coin per 10 points
    if (bonus > 0) addCoins(bonus);
    G.bonusCoins = bonus;
    G.entry = recordScore(G.score);
    save();
    stopRage(); keepAwake(false); rageAudio = play('rage', .9);
    G.shake = Math.max(G.shake, 10 * S);
  }
  function showGameOver() {
    G.overShown = true;
    $('#over-score').textContent = G.score;
    $('#over-combo').textContent = 'Best combo: ' + G.bestCombo;
    $('#over-coins').textContent = '+' + G.coinsEarned + (G.bonusCoins ? ' (' + G.bonusCoins + ' bonus)' : '');
    $('#over-best').textContent = G.score >= settings.best && G.score > 0 ? 'New best score!' : 'Best score: ' + settings.best;
    $('#hud-best').textContent = settings.best;
    $('#over-xp').textContent = '+' + G.xpEarned + ' XP';
    $('#over-level').textContent = levelInfo(settings.xp).level;
    const rank = rankOf(G.entry), rankEl = $('#over-rank'), nameRow = $('#over-name-row');
    nameRow.hidden = !G.entry;
    $('#over-name').value = settings.name === 'Player' ? '' : settings.name;
    rankEl.textContent = !G.entry ? '' :
      rank === 1 ? 'New #1 on the ' + settings.difficulty + ' leaderboard!' :
      rank > 0 && rank <= 10 ? 'You are #' + rank + ' on the ' + settings.difficulty + ' leaderboard.' :
      'Your rank: #' + (rank || '25+');
    setScreen('over');
  }

  function loseLife(x) {
    if (G.over || adm.god) return;   // admin god mode: no life is ever lost
    G.lives--; G.combo = 0; G.comboT = 0; buzz(40);
    livesImgs.forEach((im, i) => im.classList.toggle('lost', i >= G.lives));
    G.flash = Math.max(G.flash, .35); G.flashColor = '#ff2b3a';
    if (x != null) popup(clamp(x, 60, W - 60), H - 90 * S, 'Missed!', '#ff6b6b');
    if (G.lives <= 0) gameOver();
  }

  function nextArena() {
    G.bgIndex = (G.bgIndex + 1) % BACKGROUNDS.length;
    setBackground(G.bgIndex);
    $('#arena-name').textContent = BACKGROUNDS[G.bgIndex].name;
    const b = $('#banner');
    b.textContent = BACKGROUNDS[G.bgIndex].name;
    b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
  }

  function updateArenaHud() {
    const total = settings.bgSeconds;
    const left = Math.max(0, Math.ceil(total - G.bgTimer));
    $('#arena-fill').style.width = (G.bgTimer / total * 100).toFixed(1) + '%';
    if (left !== G.lastSec) {
      G.lastSec = left;
      $('#arena-time').textContent = Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
    }
  }

  function bumpScore() {
    const el = $('#hud-score');
    el.textContent = G.score;
    el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
    if (G.score > settings.best) $('#hud-best').textContent = G.score;
  }

  /* =====================================================
     Spawning
  ===================================================== */
  function spawnWave() {
    const d = DIFFICULTY[settings.difficulty];
    const maxN = 1 + Math.floor(Math.min(3, G.time / 30)) + (settings.difficulty === 'hard' ? 1 : 0);
    let n = Math.min(5, 1 + Math.floor(Math.random() * (maxN + 1)));
    if (G.frenzy > 0) n += 1;
    let bombUsed = false;
    for (let i = 0; i < n; i++) {
      let type;
      const bombP = G.frenzy > 0 ? 0 : d.bomb + Math.min(0.08, G.time / 900);
      if (!adm.noBombs && !bombUsed && Math.random() < bombP) { type = 'bomb'; bombUsed = true; }
      else if (G.frenzy <= 0 && Math.random() < 0.045) type = 'golden';
      else if (G.ice <= 0 && Math.random() < 0.035) type = 'ice';
      else if (G.lives < G.maxLives && Math.random() < 0.04) type = 'heart';
      else type = pick(FRUIT_POOL);
      G.pending.push({ delay: i * 0.12, type });
    }
  }

  function launch(type) {
    const bomb = type === 'bomb', golden = type === 'golden';
    const size = (bomb ? 80 : 104) * S;
    const x = rand(W * 0.12, W * 0.88);
    const g = H * 1.55;
    const h = H * rand(0.55, 0.88);
    const vy = -Math.sqrt(2 * g * h);
    const flight = 2 * Math.sqrt(2 * h / g);
    const target = W * 0.5 + rand(-0.25, 0.25) * W;
    G.fruits.push({
      type, bomb, golden, size, r: size * (bomb ? 0.47 : 0.52),
      img: golden ? fruitImg.orange : fruitImg[type],
      pixel: golden ? true : (bomb ? false : (FRUITS[type] ? FRUITS[type].pixel : false)),
      x, y: H + size * 0.6, vx: (target - x) / flight * rand(0.6, 1.0), vy,
      rot: rand(0, Math.PI * 2), vr: rand(-4, 4)
    });
  }

  /* =====================================================
     Slicing
  ===================================================== */
  const pointer = { x: -999, y: -999, inside: false, touch: false, trail: [] };

  function distToSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const l2 = dx * dx + dy * dy;
    let t = l2 ? ((px - x1) * dx + (py - y1) * dy) / l2 : 0;
    t = clamp(t, 0, 1);
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  }

  function handleSegment(x1, y1, x2, y2) {
    if (!G || G.paused || G.over) return;
    const len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 3) return;
    const ang = Math.atan2(y2 - y1, x2 - x1);
    for (let i = G.fruits.length - 1; i >= 0; i--) {
      const f = G.fruits[i];
      if (distToSegment(f.x, f.y, x1, y1, x2, y2) <= f.r * (AB() === 'silver-blade' ? 1.35 : 1) + (pointer.touch ? 20 : 4) * S) sliceFruit(f, ang);   // fatter hit area for fingers
    }
  }

  function sliceFruit(f, ang) {
    const ix = G.fruits.indexOf(f); if (ix < 0) return;
    G.fruits.splice(ix, 1);
    G.swipeHits++; G.swipeTimer = 0.25;

    if (f.bomb) { if (defuseBomb(f)) return; explode(f); return; }

    G.combo++; G.comboT = comboWin(); comboFx();
    const mult = (G.frenzy > 0 ? 2 : 1) * adm.mult;
    const fd = f.golden ? null : (FRUITS[f.type] || SPECIAL[f.type]);
    let pts = (f.golden ? 5 : fd.pts) * mult * comboMult();
    let coins = (f.golden ? GOLDEN_COINS : fd.coins) * mult;
    const ab = AB(); G.abN++;
    if (ab === 'katana' && G.abN % 7 === 0) { pts *= 2; popup(f.x, f.y - 70 * S, 'Crit!', '#ffd84a'); }
    if (ab === 'rengoku-nichirin' && G.combo >= 10) pts = Math.round(pts * 1.5);
    if (ab === 'enchanted-diamond' && Math.random() < 0.2) { coins += 3; popup(f.x, f.y - 70 * S, 'Fortune!', '#7cf2ff'); }
    if (ab === 'royal-gold-blade') coins *= 2;
    if (ab === 'kokushibo-katana') pts += 1;
    if (ab === 'demon-blood-sword' && G.combo >= 5) coins += 2;
    if (G.swipeHits >= 3) {
      pts += G.swipeHits * mult;
      coins += 2;
      popup(f.x, f.y - 46 * S, G.swipeHits + ' fruit combo!', '#ffd84a');
    }
    G.score += pts; bumpScore();
    addXp(pts);
    addCoins(coins, f.x, f.y);
    popup(f.x, f.y, '+' + pts, '#ffffff');
    play('slice', .85, rand(0.92, 1.12)); buzz(8);

    // two halves
    const base = ang - Math.PI / 2;
    [-1, 1].forEach(side => {
      const sep = rand(120, 220) * S;
      G.halves.push({
        x: f.x, y: f.y, size: f.size, img: f.img, golden: f.golden, pixel: f.pixel,
        vx: f.vx * 0.6 + Math.cos(base) * side * sep,
        vy: f.vy * 0.4 - rand(40, 140) * S + Math.sin(base) * side * sep,
        rot: 0, vr: side * rand(2, 5), fruitRot: f.rot, base, side
      });
    });

    // juice + splat
    const colors = f.golden ? ['#ffd84a', '#fff1a8', '#ff9f1a'] : fd.juice;
    for (let i = 0; i < 16; i++) {
      const a = rand(0, Math.PI * 2), sp = rand(120, 420) * S;
      G.particles.push({ x: f.x, y: f.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 80 * S,
        life: rand(0.45, 0.9), max: 0.9, size: rand(3, 7) * S, color: pick(colors) });
    }
    const blobs = []; for (let i = 0; i < 6; i++) blobs.push({ dx: rand(-1, 1), dy: rand(-1, 1), r: rand(0.35, 1) });
    G.splats.push({ x: f.x, y: f.y, r: rand(30, 52) * S, color: colors[0], life: 2.4, max: 2.4, blobs });
    if (G.splats.length > 18) G.splats.shift();

    if (f.golden) startFrenzy(f.x, f.y);
    if (f.type === 'ice') startIce(f.x, f.y);
    if (f.type === 'heart') healLife(f.x, f.y);
    abilityAfter(f, ang);
    G.slashes.push({ x: f.x, y: f.y, a: ang, life: .22, max: .22, len: f.size * 1.5 });
    G.rings.push({ x: f.x, y: f.y, life: .3, max: .3, color: colors[1] || '#fff', small: true });
    if (G.combo >= 5) G.hit = Math.max(G.hit, 0.04);   // tiny hit-stop for crunch
  }

  /* ---------- Mobile helpers ---------- */
  let wakeLock = null;   // keep the screen on while playing
  async function keepAwake(on) {
    try {
      if (on && navigator.wakeLock && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
      else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
    } catch (e) { wakeLock = null; }
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseGame(); else if (G && !G.over && !G.paused) keepAwake(true); });
  const fsBtn = $('#btn-full'), docEl = document.documentElement;
  if (!(docEl.requestFullscreen || docEl.webkitRequestFullscreen)) fsBtn.hidden = true;
  fsBtn.addEventListener('click', () => {
    try { if (document.fullscreenElement) document.exitFullscreen(); else (docEl.requestFullscreen || docEl.webkitRequestFullscreen).call(docEl); } catch (e) { /* not allowed */ }
  });
  const buzz = p => { try { if (pointer.touch && navigator.vibrate) navigator.vibrate(p); } catch (e) { /* no haptics */ } };
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) navigator.serviceWorker.register('sw.js').catch(() => {});

  /* ---------- Combo, ice, hearts, volleys, chimes ---------- */
  const AB = () => settings.weapon;   // id of the weapon you are holding
  const comboWin = () => AB() === 'finn-sword' ? 2.6 : AB() === 'kokushibo-katana' ? 2.1 : 1.6;
  const comboMult = () => AB() === 'neon-cyber-blade' ? Math.min(6, 1 + Math.floor(G.combo / 5)) : Math.min(5, 1 + Math.floor(G.combo / 8));
  function defuseBomb(f) {   // Zoro: cut up to 3 bombs per round without exploding
    if (AB() !== 'zoro-king-of-hell' || G.defuse <= 0) return false;
    G.defuse--; popup(f.x, f.y, 'Defused!', '#22d36b');
    G.rings.push({ x: f.x, y: f.y, life: .4, max: .4, color: '#22d36b', small: true });
    G.score += 5; bumpScore(); play('powerup', .6, 1.3);
    return true;
  }
  function nearestFruit(f, range) {
    let best = null, bd = range;
    G.fruits.forEach(o => { if (o.bomb) return; const d = Math.hypot(o.x - f.x, o.y - f.y); if (d < bd) { bd = d; best = o; } });
    return best;
  }
  function burst(x, y, range, text, color, ang) {   // slices every fruit in range (Infinity = whole screen)
    popup(x, y - 60 * S, text, color);
    G.rings.push({ x, y, life: .5, max: .5, color });
    G.flash = Math.max(G.flash, .25); G.flashColor = color; G.shake = Math.max(G.shake, 6 * S);
    G.fruits.slice().forEach(o => {
      if (o.bomb) return;
      if (range === Infinity ? (o.y < H * 0.95 && o.y > 0) : Math.hypot(o.x - x, o.y - y) < range) sliceFruit(o, ang);
    });
  }
  function abilityAfter(f, ang) {
    const ab = AB();
    if (ab === 'crystal-sword') { const o = nearestFruit(f, 230 * S); if (o) sliceFruit(o, ang); }
    else if (ab === 'night-king-ice-blade' && G.ice <= 0 && Math.random() < 0.12) { G.ice = 2; popup(f.x, f.y - 60 * S, 'Frostbite!', '#9fe4ff'); }
    else if (ab === 'ceruledge-blade' && G.abN % 25 === 0 && G.lives < G.maxLives) healLife(f.x, f.y);
    else if (ab === 'zangetsu' && G.abN % 15 === 0) burst(f.x, f.y, Infinity, 'Getsuga!', '#8f7bff', ang);
    else if (ab === 'kamish-wrath' && Math.random() < 0.08) burst(f.x, f.y, 260 * S, 'Dragon fire!', '#ff5a3a', ang);
    else if (ab === 'sanemi-nichirin' && Math.random() < 0.18) burst(f.x, f.y, 240 * S, 'Wind breathing!', '#5dff9a', ang);
    else if (ab === 'zoro-three-swords' && G.abN % 10 === 0) burst(f.x, f.y, 330 * S, 'Santoryu!', '#ff5a5a', ang);
    else if (ab === 'fionna-crystal-sword' && G.frenzy <= 0 && Math.random() < 0.04) { startFrenzy(f.x, f.y); popup(f.x, f.y - 60 * S, "Cake's blessing!", '#ff8ae0'); }
  }
  const MILESTONES = { 10: ['Nice!', '#7cf2ff'], 25: ['Awesome!', '#ffd84a'], 50: ['UNREAL!', '#ff7ad9'], 100: ['LEGENDARY!', '#ff5a3a'], 200: ['GODLIKE!', '#c28bff'] };
  const cEl = $('#combo'), cMult = $('#combo-mult'), cNum = $('#combo-n'), cBar = $('#combo-bar');
  function comboFx() {
    chime(G.combo);
    G.bestCombo = Math.max(G.bestCombo, G.combo);
    const m = MILESTONES[G.combo];
    if (!m) return;
    popup(W / 2, H * 0.34, m[0], m[1]);
    G.flash = Math.max(G.flash, .3); G.flashColor = m[1]; G.shake = Math.max(G.shake, 8 * S);
    play('powerup', .5, 1 + Math.min(.5, G.combo / 200));
  }
  function renderCombo() {
    const on = G.combo >= 2;
    if (cEl.hidden === on) cEl.hidden = !on;
    if (!on) return;
    if (G.shownCombo !== G.combo) {
      G.shownCombo = G.combo;
      cMult.textContent = 'x' + comboMult(); cNum.textContent = G.combo + ' combo';
      cEl.classList.remove('pop'); void cEl.offsetWidth; cEl.classList.add('pop');
    }
    cBar.style.width = clamp(G.comboT / comboWin(), 0, 1) * 100 + '%';
  }
  function startIce(x, y) {
    G.ice = 4; G.flash = .35; G.flashColor = '#7fd8ff';
    popup(W / 2, H * 0.3, 'Freeze!', '#9fe4ff'); play('powerup', .8, 1.3);
    for (let i = 0; i < 24; i++) {
      const a = rand(0, 6.283), sp = rand(100, 520) * S;
      G.particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: rand(.5, 1.1), max: 1.1, size: rand(3, 8) * S, color: pick(['#ffffff', '#bfefff', '#4fc3ff']) });
    }
  }
  function healLife(x, y) {
    if (G.lives < G.maxLives) {
      G.lives++; livesImgs.forEach((im, i) => im.classList.toggle('lost', i >= G.lives));
      popup(x, y - 50 * S, '+1 life!', '#ff7a9c');
    } else { G.score += 10; bumpScore(); popup(x, y - 50 * S, '+10 bonus', '#ff7a9c'); }
    G.flash = .3; G.flashColor = '#ff3d6e'; play('powerup', .7, 1.15);
  }
  function volley() {
    const n = 7 + Math.floor(Math.min(5, G.time / 40));
    for (let i = 0; i < n; i++) G.pending.push({ delay: i * 0.1, type: pick(FRUIT_POOL) });
    const b = $('#banner'); b.textContent = 'Fruit rain!';
    b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
    play('powerup', .6, 1.2);
  }
  let actx = null;   // little synth chime that climbs with your combo (no audio file needed)
  function chime(n) {
    if (!settings.sound) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
      const sc = [0, 2, 4, 7, 9, 12, 14, 16];
      const semi = sc[n % sc.length] + 12 * Math.min(2, Math.floor(n / sc.length));
      o.type = 'triangle'; o.frequency.value = 523.25 * Math.pow(2, semi / 12);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, settings.volume * 0.18), t + .01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + .22);
      o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + .25);
    } catch (e) { /* audio not available */ }
  }

  function startFrenzy(x, y) {
    G.frenzy = 6;
    $('#frenzy').hidden = false;
    play('powerup', 1);
    G.flash = .4; G.flashColor = '#ffd84a';
    popup(W / 2, H * 0.3, 'Frenzy!', '#ffd84a');
  }

  function explode(f) {
    if (AB() === 'netherite-sword' && G.shield > 0) {   // armor blocks the first bomb
      G.shield--; popup(f.x, f.y, 'Blocked!', '#c58bff');
      G.rings.push({ x: f.x, y: f.y, life: .5, max: .5, color: '#b052ff' });
      G.flash = .4; G.flashColor = '#b052ff'; play('powerup', .8, .8);
      return;
    }
    play('explosion', 1);
    buzz([60, 40, 90]); G.shake = 20 * S; G.flash = .85; G.flashColor = '#ffb347'; G.combo = 0; G.comboT = 0; G.slow = .6;
    G.rings.push({ x: f.x, y: f.y, life: .55, max: .55 });
    const colors = ['#ffe27a', '#ff8a1a', '#ff4a1a', '#2a2a33', '#ffffff'];
    for (let i = 0; i < 40; i++) {
      const a = rand(0, Math.PI * 2), sp = rand(150, 700) * S;
      G.particles.push({ x: f.x, y: f.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: rand(0.4, 1), max: 1, size: rand(3, 9) * S, color: pick(colors) });
    }
    popup(f.x, f.y, 'Boom!', '#ff8a1a');
    loseLife();
  }

  function popup(x, y, text, color) {
    G.popups.push({ x, y, text, color, life: 0.9, max: 0.9 });
  }

  /* ---------- pointer input ---------- */
  function addPoint(x, y) {
    if (pointer.inside) handleSegment(pointer.x, pointer.y, x, y);
    pointer.x = x; pointer.y = y; pointer.inside = true;
    pointer.trail.push({ x, y, t: performance.now() });
    if (pointer.trail.length > 60) pointer.trail.shift();
  }
  // touches currently down: two fingers = pinch to zoom (slicing is paused until all fingers lift)
  const touches = new Map();
  let pinch = null, pinchLock = false;
  const twoTouches = () => [...touches.values()].slice(0, 2);
  canvas.addEventListener('pointerdown', e => {
    pointer.touch = e.pointerType !== 'mouse';
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    if (pointer.touch) {
      touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (touches.size === 1) pinchLock = false;
      if (touches.size >= 2) {
        const [a, b] = twoTouches();
        pinch = { d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: ZT };
        pinchLock = true; pointer.inside = false; pointer.trail.length = 0;
        return;
      }
    }
    pointer.inside = false; pointer.trail.length = 0;
    addPoint(e.clientX / Z, e.clientY / Z);   // screen px -> world units
  });
  canvas.addEventListener('pointermove', e => {
    pointer.touch = e.pointerType !== 'mouse';
    if (touches.has(e.pointerId)) touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch) {
      if (touches.size >= 2) { const [a, b] = twoTouches(); setZoom(pinch.z0 * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d0, true); }
      return;
    }
    if (pinchLock) return;
    if (pointer.touch && e.buttons === 0 && e.pressure === 0) return; // finger not down
    const list = e.getCoalescedEvents ? e.getCoalescedEvents() : null;
    if (list && list.length) list.forEach(ev => addPoint(ev.clientX / Z, ev.clientY / Z));
    else addPoint(e.clientX / Z, e.clientY / Z);
  });
  const endPointer = e => {
    if (e && touches.delete(e.pointerId) && touches.size < 2) pinch = null;
    if (pointer.touch) { pointer.inside = false; pointer.trail.length = 0; }
  };
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);
  canvas.addEventListener('pointerleave', () => { if (!pointer.touch) { pointer.inside = false; pointer.trail.length = 0; } });
  canvas.addEventListener('contextmenu', e => e.preventDefault());

  /* =====================================================
     Update
  ===================================================== */
  function update(dt) {
    const ts = (G.frenzy > 0 ? 0.6 : 1) * (G.ice > 0 ? 0.35 : 1) * (G.slow > 0 ? 0.3 : 1) * (G.hit > 0 ? 0.08 : 1) * (AB() === 'rey-lightsaber' ? 0.8 : 1) * (adm.freeze ? 0 : adm.speed);   // frenzy slow motion x admin time controls
    const sdt = dt * ts;
    const g = H * 1.55;
    const d = DIFFICULTY[settings.difficulty];

    if (!G.over) {
      G.time += dt;

      // background changes every settings.bgSeconds (default 60 s = 1 minute)
      G.bgTimer += dt;
      if (G.bgTimer >= settings.bgSeconds) { G.bgTimer = 0; nextArena(); }
      updateArenaHud();

      if (G.frenzy > 0) { G.frenzy -= dt; if (G.frenzy <= 0) { G.frenzy = 0; $('#frenzy').hidden = true; } }

      if (!adm.freeze) G.spawnTimer -= dt * (G.ice > 0 ? 0.4 : 1);
      if (G.spawnTimer <= 0) {
        spawnWave();
        const base = Math.max(0.5, d.interval - G.time * 0.005);
        G.spawnTimer = base * (G.frenzy > 0 ? 0.55 : 1) * rand(0.85, 1.2) / adm.rate;
      }
      G.swipeTimer -= dt; if (G.swipeTimer <= 0) G.swipeHits = 0;
      if (G.combo > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
      renderCombo();
      G.volleyT -= dt;
      if (G.volleyT <= 0 && G.frenzy <= 0) { G.volleyT = rand(26, 38); volley(); }
    } else {
      G.overTimer += dt;
      if (G.overTimer > 0.9 && !G.overShown) showGameOver();
    }

    for (let i = G.pending.length - 1; i >= 0; i--) {
      G.pending[i].delay -= dt;
      if (G.pending[i].delay <= 0) { if (!G.over) launch(G.pending[i].type); G.pending.splice(i, 1); }
    }

    for (let i = G.fruits.length - 1; i >= 0; i--) {
      const f = G.fruits[i];
      f.vy += g * sdt; f.x += f.vx * sdt; f.y += f.vy * sdt; f.rot += f.vr * sdt;
      if (f.y > H + f.size && f.vy > 0) {
        G.fruits.splice(i, 1);
        if (!f.bomb && !f.golden && !SPECIAL[f.type]) loseLife(f.x);
      }
    }
    if (adm.auto && !G.over) {   // admin auto-slice: cut every fruit once it is on screen
      G.fruits.slice().forEach(f => { if (!f.bomb && f.y < H * 0.9 && f.y > 0) sliceFruit(f, rand(0, Math.PI * 2)); });
    }
    for (let i = G.halves.length - 1; i >= 0; i--) {
      const h = G.halves[i];
      h.vy += g * sdt; h.x += h.vx * sdt; h.y += h.vy * sdt; h.rot += h.vr * sdt;
      if (h.y > H + h.size * 2) G.halves.splice(i, 1);
    }
    for (let i = G.particles.length - 1; i >= 0; i--) {
      const p = G.particles[i];
      p.vy += g * 0.5 * sdt; p.x += p.vx * sdt; p.y += p.vy * sdt; p.life -= dt;
      if (p.life <= 0) G.particles.splice(i, 1);
    }
    [G.splats, G.rings, G.popups, G.coinFx, G.slashes].forEach(list => {
      for (let i = list.length - 1; i >= 0; i--) { list[i].life -= dt; if (list[i].life <= 0) list.splice(i, 1); }
    });
    G.popups.forEach(p => { p.y -= 50 * S * dt; });
    G.ice = Math.max(0, G.ice - dt); G.slow = Math.max(0, G.slow - dt); G.hit = Math.max(0, G.hit - dt);
    G.shake = Math.max(0, G.shake - 45 * dt);
    G.flash = Math.max(0, G.flash - 1.8 * dt);
  }

  /* =====================================================
     Render
  ===================================================== */
  const FONT = '"Titan One", Impact, "Arial Black", sans-serif';

  function render() {
    ctx.setTransform(DPR * Z, 0, 0, DPR * Z, 0, 0);
    ctx.clearRect(-4, -4, W + 8, H + 8);
    ctx.save();
    if (G.shake > 0) ctx.translate(rand(-G.shake, G.shake), rand(-G.shake, G.shake));

    // juice splats on the background
    G.splats.forEach(s => {
      ctx.globalAlpha = clamp(s.life / s.max, 0, 1) * 0.5;
      ctx.fillStyle = s.color;
      s.blobs.forEach(b => { ctx.beginPath(); ctx.arc(s.x + b.dx * s.r * .6, s.y + b.dy * s.r * .6, s.r * b.r * .6, 0, 6.283); ctx.fill(); });
    });
    ctx.globalAlpha = 1;

    // halves
    G.halves.forEach(h => {
      ctx.save();
      ctx.translate(h.x, h.y); ctx.rotate(h.rot); ctx.rotate(h.base);
      ctx.beginPath();
      const s = h.size;
      if (h.side < 0) ctx.rect(-s, -s, s, 2 * s); else ctx.rect(0, -s, s, 2 * s);
      ctx.clip();
      ctx.rotate(-h.base); ctx.rotate(h.fruitRot);
      ctx.imageSmoothingEnabled = !h.pixel;
      if (h.golden) { ctx.shadowColor = '#ffd84a'; ctx.shadowBlur = 24 * S; }
      ctx.drawImage(h.img, -s / 2, -s / 2, s, s);
      ctx.restore();
    });

    // whole fruits and bombs
    G.fruits.forEach(f => {
      ctx.save();
      ctx.translate(f.x, f.y); ctx.rotate(f.rot);
      if (f.bomb) drawBomb(f);
      else {
        ctx.imageSmoothingEnabled = !f.pixel;
        if (f.golden) { ctx.shadowColor = '#ffd84a'; ctx.shadowBlur = (28 + 10 * Math.sin(G.time * 9)) * S; }
        else { ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 16 * S; ctx.shadowOffsetY = 6 * S; }
        ctx.drawImage(f.img, -f.size / 2, -f.size / 2, f.size, f.size);
      }
      ctx.restore();
      if (f.golden) sparkles(f);
    });
    ctx.imageSmoothingEnabled = true;

    // coins flying to the counter
    G.coinFx.forEach(c => {
      const t = clamp(1 - c.life / c.max, 0, 1), e = t * t;
      const x = c.x0 + (c.tx - c.x0) * e, y = c.y0 + (c.ty - c.y0) * e - Math.sin(t * Math.PI) * 60 * S;
      ctx.fillStyle = '#9a6400'; ctx.beginPath(); ctx.arc(x, y, 10 * S, 0, 6.283); ctx.fill();
      ctx.fillStyle = '#ffcf3d'; ctx.beginPath(); ctx.arc(x, y, 7.5 * S, 0, 6.283); ctx.fill();
      ctx.fillStyle = '#fff3a8'; ctx.beginPath(); ctx.arc(x - 2 * S, y - 2 * S, 2.5 * S, 0, 6.283); ctx.fill();
    });

    // particles
    G.particles.forEach(p => {
      ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, 6.283); ctx.fill();
    });
    ctx.globalAlpha = 1;

    // explosion rings
    G.rings.forEach(r => {
      const t = 1 - r.life / r.max;
      ctx.globalAlpha = 1 - t; ctx.strokeStyle = r.color || '#fff3c4'; ctx.lineWidth = (r.small ? 5 : 10) * S * (1 - t) + 2;
      ctx.beginPath(); ctx.arc(r.x, r.y, (r.small ? 14 : 20) * S + t * (r.small ? 100 : 220) * S, 0, 6.283); ctx.stroke();
    });
    ctx.globalAlpha = 1;

    G.slashes.forEach(sl => {   // bright slash flash through each sliced fruit
      const k = clamp(sl.life / sl.max, 0, 1), l = sl.len * (1.2 - k * .2);
      ctx.save(); ctx.translate(sl.x, sl.y); ctx.rotate(sl.a); ctx.globalAlpha = k;
      const g = ctx.createLinearGradient(-l, 0, l, 0);
      g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(.5, '#fff'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.shadowColor = '#fff'; ctx.shadowBlur = 14 * S;
      ctx.fillRect(-l, -2.5 * S * k - 1, 2 * l, 5 * S * k + 2); ctx.restore();
    });
    drawTrail();

    // score popups
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    G.popups.forEach(p => {
      ctx.globalAlpha = clamp(p.life / p.max * 1.6, 0, 1);
      ctx.font = `${30 * S}px ${FONT}`;
      ctx.lineWidth = 7 * S; ctx.strokeStyle = '#17112a'; ctx.strokeText(p.text, p.x, p.y);
      ctx.fillStyle = p.color; ctx.fillText(p.text, p.x, p.y);
    });
    ctx.globalAlpha = 1;

    drawWeapon();
    ctx.restore();

    if (G.flash > 0) {
      ctx.globalAlpha = clamp(G.flash, 0, 1) * 0.55;
      ctx.fillStyle = G.flashColor; ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (G.ice > 0 || G.frenzy > 0 || G.combo >= 8) {   // edge glow: blue = freeze, gold = frenzy, pink = hot streak
      const col = G.ice > 0 ? '90,200,255' : G.frenzy > 0 ? '255,200,60' : '255,120,220';
      const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * .35, W / 2, H / 2, Math.max(W, H) * .75);
      vg.addColorStop(0, 'rgba(' + col + ',0)'); vg.addColorStop(1, 'rgba(' + col + ',' + (.32 + .1 * Math.sin(G.time * 6)).toFixed(2) + ')');
      ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    }
  }

  function drawBomb(f) {
    const r = f.size * 0.46;
    const gr = ctx.createRadialGradient(-r * .35, -r * .4, r * .1, 0, 0, r);
    gr.addColorStop(0, '#6a6a80'); gr.addColorStop(.5, '#26242f'); gr.addColorStop(1, '#0b0a11');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, r, 0, 6.283); ctx.fill();
    ctx.lineWidth = 3 * S; ctx.strokeStyle = '#000'; ctx.stroke();
    // cap and fuse
    ctx.fillStyle = '#3b3947'; ctx.fillRect(-r * .24, -r * 1.12, r * .48, r * .3);
    ctx.strokeStyle = '#c9a46a'; ctx.lineWidth = 4 * S; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, -r * 1.1); ctx.quadraticCurveTo(r * .3, -r * 1.55, r * .62, -r * 1.38); ctx.stroke();
    const sp = (Math.sin(G.time * 30) + 1) / 2;
    ctx.fillStyle = sp > .5 ? '#ffe27a' : '#ff7a1a';
    ctx.beginPath(); ctx.arc(r * .62, -r * 1.38, (5 + 4 * sp) * S, 0, 6.283); ctx.fill();
    // red warning mark
    ctx.fillStyle = 'rgba(255,60,60,' + (0.55 + 0.35 * Math.sin(G.time * 10)) + ')';
    ctx.beginPath(); ctx.arc(0, r * .1, r * .26, 0, 6.283); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.fillRect(-r * .04, -r * .1, r * .08, r * .26); ctx.fillRect(-r * .04, r * .22, r * .08, r * .08);
  }

  function sparkles(f) {
    ctx.save();
    ctx.fillStyle = '#fff6c4';
    for (let i = 0; i < 3; i++) {
      const a = G.time * 3 + i * 2.1, d = f.size * 0.62;
      const x = f.x + Math.cos(a) * d, y = f.y + Math.sin(a) * d;
      const s = (5 + 3 * Math.sin(G.time * 8 + i)) * S;
      ctx.beginPath(); ctx.moveTo(x, y - s * 1.6); ctx.lineTo(x + s * .5, y); ctx.lineTo(x, y + s * 1.6); ctx.lineTo(x - s * .5, y); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  function weaponDef() { return WEAPONS.find(w => w.id === settings.weapon) || WEAPONS[0]; }

  function drawTrail() {
    const now = performance.now(), LIFE = 220, tr = pointer.trail;
    while (tr.length && now - tr[0].t > LIFE) tr.shift();
    if (!settings.trail || tr.length < 2) return;
    let w = weaponDef();
    if (G && G.combo >= 15) { const h = (now / 4) % 360; w = { ...w, glow: 'hsl(' + h + ',100%,60%)', trail: 'hsl(' + ((h + 40) % 360) + ',100%,85%)' }; }
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    [{ c: w.glow, w: 16, a: .6, blur: 18 }, { c: w.trail, w: 6, a: 1, blur: 0 }].forEach(pass => {
      ctx.shadowColor = w.glow; ctx.shadowBlur = pass.blur;
      ctx.strokeStyle = pass.c;
      for (let i = 1; i < tr.length; i++) {
        const age = clamp(1 - (now - tr[i].t) / LIFE, 0, 1);
        ctx.globalAlpha = age * pass.a;
        ctx.lineWidth = Math.max(1, pass.w * S * age);
        ctx.beginPath(); ctx.moveTo(tr[i - 1].x, tr[i - 1].y); ctx.lineTo(tr[i].x, tr[i].y); ctx.stroke();
      }
    });
    ctx.globalAlpha = 1; ctx.shadowBlur = 0;
  }

  function drawWeapon() {
    if (!pointer.inside || pointer.touch) return;   // the finger would hide the blade
    const w = weaponDef(), img = weaponImg[w.id];
    if (!img.complete || !img.naturalWidth) return;
    const fw = w.frames ? w.fw : img.naturalWidth;
    const fh = w.frames ? w.fh : img.naturalHeight;
    const k = ((w.pixel ? 100 : 110) / Math.max(fw, fh)) * S * settings.weaponSize;
    ctx.imageSmoothingEnabled = !w.pixel;
    if (w.frames) {
      const fi = Math.floor(performance.now() / 1000 * w.fps) % w.frames;   // animated blade
      const ox = w.hx !== undefined ? w.hx * k : 1 * k, oy = w.hy !== undefined ? w.hy * k : 0;   // cursor hotspot = blade tip
      ctx.drawImage(img, fi * fw, 0, fw, fh, pointer.x - ox, pointer.y - oy, fw * k, fh * k);
    } else {
      const ox = w.hx !== undefined ? w.hx * k : 2, oy = w.hy !== undefined ? w.hy * k : 2;
      ctx.drawImage(img, pointer.x - ox, pointer.y - oy, fw * k, fh * k);
    }
    ctx.imageSmoothingEnabled = true;
  }

  /* =====================================================
     Main loop
  ===================================================== */
  function loop(now) {
    if (!G) return;
    const dt = Math.min(0.05, (now - lastT) / 1000);
    lastT = now;
    if (dt > 0) adm.fps = adm.fps * 0.9 + (1 / dt) * 0.1;
    easeZoom(dt);
    if (!G.paused) update(dt);
    render();
    loopId = requestAnimationFrame(loop);
  }

  /* =====================================================
     Admin bridge (used by admin.js, the PIN protected console)
     The cheat flags below are read by the game loop above.
  ===================================================== */
  window.FS_ADMIN = {
    cheats: adm,
    get settings() { return settings; },
    get game() { return G; },
    WEAPONS, FRUITS, DIFFICULTY, BACKGROUNDS, DEFAULTS, MUSIC_TRACKS,
    setTrack(id) { settings.track = id; save(); syncSettingsUI(); applyMusic(); },
    ROSTER_KEY, PID_RE, makePid, sanitizeSettings,
    useProfile(obj) {   // swap the active player (owner console)
      save();
      Object.keys(settings).forEach(k => delete settings[k]);
      Object.assign(settings, JSON.parse(JSON.stringify(DEFAULTS)), obj || {});
      sanitizeSettings(); save();
      this.refresh(); applyMusic();
    },
    isOwned, save, weaponDef, levelInfo, xpForNext, addXp, cleanName,
    PASS_COST, PASS_MAX, passInfo, passNeed, grantPass, addPassXp, buyPass,
    refresh() { renderCoins(); renderLevel(); renderMenuInfo(); renderSpinUI(); buildWeapons(); syncSettingsUI(); renderPass(); buildPassList(); save(); },
    round() { return G && !G.over ? G : null; },
    pause() { if (G && !G.over && !G.paused) { pauseGame(); return true; } return false; },
    resume() { if (G && G.paused) resumeGame(); },
    setLives(n) {
      if (!G || G.over) return;
      G.maxLives = Math.max(G.maxLives, n); G.lives = n; buildLives();
      livesImgs.forEach((im, i) => im.classList.toggle('lost', i >= G.lives));
    },
    setScore(n) { if (!G || G.over) return; G.score = n; $('#hud-score').textContent = n; },
    spawn(type, n = 1) { if (!G || G.over) return; for (let i = 0; i < n; i++) G.pending.push({ delay: i * 0.1, type }); },
    frenzy() { if (G && !G.over) startFrenzy(); },
    nuke() {
      if (!G || G.over) return;
      G.fruits.slice().forEach(f => { if (f.bomb) G.fruits.splice(G.fruits.indexOf(f), 1); else sliceFruit(f, rand(0, Math.PI * 2)); });
      G.shake = 26 * S; G.flash = .6; G.flashColor = '#ffffff';
    },
    purge() { if (G) { G.fruits.length = 0; G.pending.length = 0; } },
    setArena(i) {
      if (!G) return;
      G.bgIndex = ((i % BACKGROUNDS.length) + BACKGROUNDS.length) % BACKGROUNDS.length; G.bgTimer = 0;
      setBackground(G.bgIndex); $('#arena-name').textContent = BACKGROUNDS[G.bgIndex].name;
    }
  };

  /* =====================================================
     Start
  ===================================================== */
  syncSettingsUI();
  renderCoins(); renderLevel();
  recoverPending();
  enterMenu('menu');
})();
