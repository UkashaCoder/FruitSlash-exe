/* =====================================================
   ADMIN//CORE  -  PIN protected admin console for Fruit Slash
   Open: the ADMIN button on the main menu, or the ` key.
   Needs game.js (it exposes window.FS_ADMIN).

   Note: this is a browser game, so the PIN only keeps casual
   players out. Anyone who edits the files can bypass it.
===================================================== */
(() => {
  'use strict';
  const FS = window.FS_ADMIN;
  if (!FS) return;

  /* ---------- tiny helpers ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const strip = h => String(h).replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  const pad2 = n => String(n).padStart(2, '0');
  const stamp = d => { d = d || new Date(); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()); };
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const S = () => FS.settings;
  const cheats = FS.cheats;

  const HASH = '1xumfrlihob';                       // hash of the PIN (the PIN itself is not stored in the code)
  const LOCK_KEY = 'fruitSlash.adminLock', THEME_KEY = 'fruitSlash.adminTheme', AUDIT_KEY = 'fruitSlash.adminAudit';
  const THEMES = ['cyan', 'green', 'magenta', 'amber', 'red'];
  const hashPin = s => {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  };
  const ls = {
    get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
  };

  const st = { open: false, authed: false, booted: false, tab: 'terminal', fails: 0, hist: [], hi: 0, spawnN: 1, wq: '', pausedByMe: false };
  let audit = []; try { audit = JSON.parse(ls.get(AUDIT_KEY) || '[]'); if (!Array.isArray(audit)) audit = []; } catch (e) { audit = []; }
  const addAudit = text => { audit.push({ t: Date.now(), x: text }); if (audit.length > 100) audit.shift(); ls.set(AUDIT_KEY, JSON.stringify(audit)); };

  /* ---------- sound (little synth blips; follows the game's sound setting) ---------- */
  let actx;
  function beep(f = 660, d = .06, type = 'square', v = .035, when = 0) {
    if (!S().sound) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime + when;
      o.type = type; o.frequency.value = f;
      g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
      o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + d + .02);
    } catch (e) { /* ignore */ }
  }
  const sfx = {
    key: () => beep(900 + Math.random() * 300, .025, 'square', .015),
    tab: () => beep(520, .04, 'square', .03),
    ok: () => { beep(660, .07, 'triangle', .05); beep(990, .09, 'triangle', .05, .07); },
    err: () => { beep(150, .2, 'sawtooth', .06); beep(110, .2, 'sawtooth', .06, .1); },
    open: () => { beep(240, .18, 'sine', .06); beep(480, .14, 'sine', .04, .06); },
    grant: () => [520, 660, 784, 1046].forEach((f, i) => beep(f, .13, 'triangle', .05, i * .08))
  };

  /* =====================================================
     Build the UI
  ===================================================== */
  const root = document.createElement('div');
  root.id = 'adm-root'; root.hidden = true;
  root.dataset.theme = THEMES.includes(ls.get(THEME_KEY)) ? ls.get(THEME_KEY) : 'cyan';
  root.innerHTML = `
  <div class="adm-win" role="dialog" aria-label="Admin console">
    <div class="adm-crt"></div>
    <header class="adm-head">
      <div class="adm-logo" data-text="ADMIN//CORE">ADMIN//CORE</div>
      <span class="adm-pill" id="adm-pill">LOCKED</span>
      <span class="adm-sp"></span>
      <span class="adm-meter" title="Frames per second"><canvas id="adm-spark" width="180" height="44"></canvas><b id="adm-fps">--</b><small>FPS</small></span>
      <span class="adm-clock" id="adm-clock">00:00:00</span>
      <button class="adm-ic" id="adm-theme" type="button" title="Change color theme"><i class="sw"></i></button>
      <button class="adm-ic" id="adm-x" type="button" title="Close (Esc)">&#10005;</button>
    </header>

    <section class="adm-gate" id="adm-gate">
      <canvas id="adm-rain"></canvas>
      <div class="adm-gate-card">
        <svg class="adm-lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4.5" y="10.5" width="15" height="10" rx="2.2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.3" fill="currentColor"/></svg>
        <h2 class="adm-glitch" data-text="RESTRICTED AREA">RESTRICTED AREA</h2>
        <p>Authorized players only. Enter the admin PIN.</p>
        <label class="adm-pinbox"><span id="adm-dots"></span><input id="adm-pin" type="password" maxlength="40" autocomplete="off" autocapitalize="characters" spellcheck="false" aria-label="Admin PIN"></label>
        <button class="adm-btn big" id="adm-go" type="button">AUTHENTICATE</button>
        <div class="adm-gmsg" id="adm-gmsg" aria-live="polite"></div>
      </div>
      <div class="adm-granted" id="adm-granted" hidden>ACCESS GRANTED</div>
    </section>

    <section class="adm-main" id="adm-main" hidden>
      <nav class="adm-tabs" role="tablist">
        <button type="button" role="tab" data-tab="terminal">TERMINAL<kbd>Alt 1</kbd></button>
        <button type="button" role="tab" data-tab="dashboard">DASHBOARD<kbd>Alt 2</kbd></button>
        <button type="button" role="tab" data-tab="weapons">WEAPONS<kbd>Alt 3</kbd></button>
        <button type="button" role="tab" data-tab="cheats">CHEATS<kbd>Alt 4</kbd></button>
      </nav>
      <div class="adm-panels">

        <div class="adm-panel" data-panel="terminal">
          <canvas id="adm-rain2"></canvas>
          <div class="adm-log" id="adm-log" aria-live="polite"></div>
          <div class="adm-quick" id="adm-quick">
            <button type="button" data-q="help">help</button><button type="button" data-q="stats">stats</button>
            <button type="button" data-q="weapons">weapons</button><button type="button" data-q="cheats">cheats</button>
            <button type="button" data-q="god">god</button><button type="button" data-q="log">log</button>
            <button type="button" data-q="clear">clear</button>
          </div>
          <form class="adm-form" id="adm-form" autocomplete="off">
            <span class="adm-prompt">root@fruit&gt;</span>
            <span class="adm-field"><span class="adm-ghost" id="adm-ghost"></span><input id="adm-cmd" type="text" spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="Command"></span>
          </form>
        </div>

        <div class="adm-panel" data-panel="dashboard">
          <div class="adm-grid">
            <div class="adm-card"><h3>COINS<span class="tag">ECONOMY</span></h3>
              <div class="adm-big"><span data-n="coins">0</span></div>
              <div class="adm-row">
                <button class="adm-btn" data-do="coins add 100">+100</button><button class="adm-btn" data-do="coins add 1k">+1K</button>
                <button class="adm-btn" data-do="coins add 10k">+10K</button><button class="adm-btn" data-do="coins add 100k">+100K</button>
              </div>
              <div class="adm-row"><input class="adm-in num" id="d-coins" data-do="coins set {d-coins}" placeholder="amount" inputmode="numeric" autocomplete="off">
                <button class="adm-btn" data-do="coins set {d-coins}">SET</button><button class="adm-btn danger" data-do="coins set 0">ZERO</button></div>
            </div>
            <div class="adm-card"><h3>SPIN TICKETS<span class="tag">ECONOMY</span></h3>
              <div class="adm-big"><span data-n="tickets">0</span></div>
              <div class="adm-row">
                <button class="adm-btn" data-do="tickets add 1">+1</button><button class="adm-btn" data-do="tickets add 5">+5</button>
                <button class="adm-btn" data-do="tickets add 25">+25</button><button class="adm-btn warn" data-do="spin reset">FREE SPIN READY</button>
              </div>
              <div class="adm-row"><input class="adm-in num" id="d-tickets" data-do="tickets set {d-tickets}" placeholder="amount" inputmode="numeric" autocomplete="off">
                <button class="adm-btn" data-do="tickets set {d-tickets}">SET</button></div>
            </div>
            <div class="adm-card"><h3>LEVEL<span class="tag" data-b="xptag">XP</span></h3>
              <div class="adm-big"><span data-b="level">1</span><small data-b="xptext">0 / 100 XP</small></div>
              <div class="adm-bar"><i data-b="xpbar"></i></div>
              <div class="adm-row">
                <button class="adm-btn" data-do="xp add 100">+100 XP</button><button class="adm-btn" data-do="xp add 1000">+1K XP</button>
                <button class="adm-btn" data-do="level +1">+1 LEVEL</button>
              </div>
              <div class="adm-row"><input class="adm-in num" id="d-level" data-do="level {d-level}" placeholder="level" inputmode="numeric" autocomplete="off">
                <button class="adm-btn" data-do="level {d-level}">SET LEVEL</button></div>
            </div>
            <div class="adm-card"><h3>LIVE ROUND<span class="tag off" data-b="rtag">NO ROUND</span></h3>
              <div class="adm-stat">
                <div>SCORE<b data-b="score">--</b></div><div>LIVES<b class="adm-hearts" data-b="lives">--</b></div>
                <div>TIME<b data-b="time">--</b></div><div>FRUIT ON SCREEN<b data-b="fruit">--</b></div>
              </div>
              <div class="adm-row">
                <button class="adm-btn" data-round data-do="lives +1">+1 LIFE</button><button class="adm-btn" data-round data-do="lives full">FULL LIVES</button>
                <button class="adm-btn warn" data-round data-do="frenzy">FRENZY</button><button class="adm-btn danger" data-round data-do="nuke">NUKE</button>
              </div>
              <p class="adm-sub" data-b="rhint" style="margin:8px 0 0">Start a round (Play), then open the console with the <b>&#96;</b> key to use these.</p>
            </div>
            <div class="adm-card"><h3>PLAYER<span class="tag">PROFILE</span></h3>
              <div class="adm-row" style="margin-top:0"><input class="adm-in" id="d-name" data-do="name {d-name}" maxlength="14" placeholder="name" autocomplete="off" style="flex:1">
                <button class="adm-btn" data-do="name {d-name}">RENAME</button></div>
              <div class="adm-row"><div class="adm-seg" role="radiogroup" aria-label="Difficulty">
                <button type="button" role="radio" data-b="diff-easy" data-do="difficulty easy">EASY</button>
                <button type="button" role="radio" data-b="diff-normal" data-do="difficulty normal">NORMAL</button>
                <button type="button" role="radio" data-b="diff-hard" data-do="difficulty hard">HARD</button></div></div>
              <div class="adm-stat"><div>BEST SCORE<b data-b="best">0</b></div><div>WEAPONS<b data-b="owned">1</b></div></div>
              <div class="adm-row"><button class="adm-btn" data-do="best reset">RESET BEST</button><button class="adm-btn" data-do="scores clear">CLEAR BOARD</button></div>
            </div>
            <div class="adm-card"><h3>DANGER ZONE<span class="tag off">CAREFUL</span></h3>
              <p class="adm-sub" style="margin:0 0 4px">Back up your save or wipe it completely.</p>
              <div class="adm-row"><button class="adm-btn" data-do="export">COPY SAVE</button>
                <button class="adm-btn danger" data-confirm data-do="reset all confirm">RESET EVERYTHING</button></div>
            </div>
          </div>
        </div>

        <div class="adm-panel" data-panel="weapons">
          <div class="adm-bar2">
            <input class="adm-in" id="w-q" placeholder="search weapons..." autocomplete="off">
            <button class="adm-btn" data-do="unlock all">UNLOCK ALL</button>
            <button class="adm-btn danger" data-do="lock all">LOCK ALL</button>
          </div>
          <div class="adm-wgrid" id="adm-wgrid"></div>
        </div>

        <div class="adm-panel" data-panel="cheats">
          <div class="adm-grid">
            <div class="adm-card"><h3>POWERS<span class="tag live" id="c-count">0 ACTIVE</span></h3>
              <button class="adm-sw" role="switch" data-do="god toggle" data-sw="god"><span>God mode<small>Never lose a life, bombs can't hurt</small></span><i class="knob"></i></button>
              <button class="adm-sw" role="switch" data-do="auto toggle" data-sw="auto"><span>Auto-slice<small>Every fruit gets cut automatically</small></span><i class="knob"></i></button>
              <button class="adm-sw" role="switch" data-do="nobombs toggle" data-sw="noBombs"><span>No bombs<small>Bombs stop spawning</small></span><i class="knob"></i></button>
              <button class="adm-sw" role="switch" data-do="freeze toggle" data-sw="freeze"><span>Freeze time<small>Fruit hangs in mid-air, spawns pause</small></span><i class="knob"></i></button>
              <div class="adm-row"><button class="adm-btn danger" data-do="cheats off">DISABLE ALL</button></div>
            </div>
            <div class="adm-card"><h3>TUNING<span class="tag">LIVE</span></h3>
              <div class="adm-slide"><span>Time scale</span><output data-out="speed">1x</output><input type="range" data-slide="speed" min="0.1" max="3" step="0.1" value="1"></div>
              <div class="adm-slide"><span>Spawn rate</span><output data-out="rate">1x</output><input type="range" data-slide="rate" min="0.25" max="6" step="0.25" value="1"></div>
              <div class="adm-sub" style="margin-top:6px">Score &amp; coin multiplier</div>
              <div class="adm-row" style="margin-top:6px"><div class="adm-seg" role="radiogroup" aria-label="Multiplier">
                <button type="button" role="radio" data-mult="1" data-do="mult 1">1x</button><button type="button" role="radio" data-mult="2" data-do="mult 2">2x</button>
                <button type="button" role="radio" data-mult="5" data-do="mult 5">5x</button><button type="button" role="radio" data-mult="10" data-do="mult 10">10x</button>
                <button type="button" role="radio" data-mult="50" data-do="mult 50">50x</button></div></div>
            </div>
            <div class="adm-card"><h3>ROUND ACTIONS<span class="tag off" data-b="rtag2">NO ROUND</span></h3>
              <div class="adm-row" style="margin-top:0">
                <button class="adm-btn warn" data-round data-do="frenzy">FRENZY</button><button class="adm-btn danger" data-round data-do="nuke">NUKE SCREEN</button>
                <button class="adm-btn" data-round data-do="purge">PURGE</button><button class="adm-btn" data-round data-do="arena next">NEXT ARENA</button>
                <button class="adm-btn" data-round data-do="lives +1">+1 LIFE</button><button class="adm-btn" data-round data-do="lives full">FULL LIVES</button>
              </div>
              <p class="adm-note" id="c-note">Start a round to use round actions.</p>
            </div>
            <div class="adm-card" style="grid-column:1/-1"><h3>SPAWNER<span class="tag off" data-b="rtag3">NO ROUND</span></h3>
              <div class="adm-row" style="margin-top:0"><span class="adm-sub">Amount</span><div class="adm-seg" role="radiogroup" aria-label="Spawn amount">
                <button type="button" role="radio" data-sn="1">x1</button><button type="button" role="radio" data-sn="5">x5</button><button type="button" role="radio" data-sn="10">x10</button><button type="button" role="radio" data-sn="25">x25</button></div></div>
              <div class="adm-spawn" id="adm-spawn"></div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <footer class="adm-foot">
      <span>SCENE <b id="f-scene">menu</b></span><span>ROUND <b id="f-round">none</b></span><span>CHEATS <b id="f-cheats">0</b></span>
      <span class="sp"></span><span>LAST <b id="f-last">-</b></span><span>THEME <b id="f-theme"></b></span>
    </footer>
    <div class="adm-toast" id="adm-toast" role="status"></div>
  </div>`;
  document.body.append(root);

  const openBtn = document.createElement('button');
  openBtn.type = 'button'; openBtn.className = 'adm-open'; openBtn.setAttribute('aria-label', 'Open admin console');
  openBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>ADMIN';
  const chipsEl = document.createElement('div'); chipsEl.className = 'adm-chips'; chipsEl.setAttribute('aria-label', 'Active admin cheats');
  document.body.append(openBtn, chipsEl);

  const win = $('.adm-win', root), gate = $('#adm-gate'), main = $('#adm-main'), pill = $('#adm-pill');
  const pin = $('#adm-pin'), dots = $('#adm-dots'), go = $('#adm-go'), gmsg = $('#adm-gmsg'), granted = $('#adm-granted');
  const logEl = $('#adm-log'), inp = $('#adm-cmd'), ghost = $('#adm-ghost'), toastEl = $('#adm-toast');

  /* =====================================================
     Matrix rain + FPS meter
  ===================================================== */
  const rains = {};
  function startRain(key, cv) {
    stopRain(key);
    const c = cv.getContext('2d'), size = 16, chars = '01ABCDEFGHJKLMNPQRSTUVWXYZ$#@%&*+=<>/';
    let w = 0, h = 0, cols = [], id = 0, last = 0, col = '#0ff';
    const fit = () => {
      w = cv.width = Math.max(1, cv.offsetWidth); h = cv.height = Math.max(1, cv.offsetHeight);   // layout size, unaffected by the power-on animation
      cols = Array.from({ length: Math.ceil(w / size) }, () => Math.random() * h / size * 0.6 - 6);
      c.fillStyle = '#060914'; c.fillRect(0, 0, w, h);
      col = getComputedStyle(root).getPropertyValue('--ac').trim() || '#0ff';
    };
    const step = t => {
      id = requestAnimationFrame(step);
      if (t - last < 55) return; last = t;
      c.fillStyle = 'rgba(6, 9, 20, .13)'; c.fillRect(0, 0, w, h);
      c.font = size + 'px monospace'; c.fillStyle = col;
      cols.forEach((y, i) => {
        if (y > 0) c.fillText(chars[(Math.random() * chars.length) | 0], i * size, y * size);
        cols[i] = (y * size > h && Math.random() > .975) ? Math.random() * -10 : y + 1;
      });
    };
    fit(); id = requestAnimationFrame(step);
    rains[key] = () => cancelAnimationFrame(id);
  }
  function stopRain(key) { if (rains[key]) { rains[key](); delete rains[key]; } }

  let fpsRaf = 0, fl = 0, facc = 0, fframes = 0, clockT = 0, liveT = 0;
  const fhist = Array(45).fill(0);
  function drawSpark() {
    const cv = $('#adm-spark'), c = cv.getContext('2d'), w = cv.width, h = cv.height;
    c.clearRect(0, 0, w, h);
    c.strokeStyle = getComputedStyle(root).getPropertyValue('--ac').trim() || '#0ff'; c.lineWidth = 2; c.lineJoin = 'round';
    c.beginPath();
    fhist.forEach((f, i) => { const x = i / (fhist.length - 1) * w, y = h - 3 - Math.min(1, f / 144) * (h - 6); i ? c.lineTo(x, y) : c.moveTo(x, y); });
    c.stroke();
  }
  function fpsLoop(t) {
    fpsRaf = requestAnimationFrame(fpsLoop);
    if (fl) { facc += t - fl; fframes++; if (facc >= 500) { const f = fframes * 1000 / facc; fhist.push(f); fhist.shift(); $('#adm-fps').textContent = Math.round(f); drawSpark(); facc = 0; fframes = 0; } }
    fl = t;
  }
  function startFx() {
    fl = 0; facc = 0; fframes = 0; cancelAnimationFrame(fpsRaf); fpsRaf = requestAnimationFrame(fpsLoop);
    clearInterval(clockT); clockT = setInterval(() => { $('#adm-clock').textContent = stamp(); }, 1000); $('#adm-clock').textContent = stamp();
    clearInterval(liveT); liveT = setInterval(live, 500);
  }
  function stopFx() { cancelAnimationFrame(fpsRaf); clearInterval(clockT); clearInterval(liveT); stopRain('gate'); stopRain('term'); }

  /* =====================================================
     Terminal output
  ===================================================== */
  function line(html, cls = 'info') {
    const d = document.createElement('div'); d.className = 'ln ln-' + cls;
    d.innerHTML = '<time>' + stamp() + '</time><span>' + html + '</span>';
    logEl.appendChild(d);
    while (logEl.children.length > 400) logEl.firstChild.remove();
    logEl.scrollTop = logEl.scrollHeight;
    return d;
  }
  const print = (text, cls) => line(esc(text), cls);
  async function typeLine(text, cls = 'info', ms = 12) {
    const d = line('', cls), sp = $('span', d);
    for (const ch of text) { sp.textContent += ch; if (ms) await sleep(ms); }
    logEl.scrollTop = logEl.scrollHeight;
  }

  /* =====================================================
     Commands
  ===================================================== */
  const C = {};
  const ALIAS = { '?': 'help', cls: 'clear', q: 'exit', quit: 'exit', gm: 'god', coin: 'coins', ticket: 'tickets', w: 'weapons', lvl: 'level', cheat: 'cheats' };
  const READONLY = new Set(['help', 'clear', 'history', 'log', 'stats', 'weapons', 'whoami', 'echo', 'banner', 'exit', 'matrix', 'theme']);
  const GROUPS = ['economy', 'player', 'weapons', 'round', 'cheats', 'system'];
  const def = (name, group, usage, desc, run, comp) => { C[name] = { name, group, usage, desc, run, comp }; };
  const fail = m => { throw new Error(m); };
  const NEED_ROUND = 'No round running. Press Play, then open the console with ` .';
  const resolve = n => { n = String(n || '').toLowerCase(); return C[n] ? n : (ALIAS[n] || null); };
  const round = () => FS.round() || fail(NEED_ROUND);

  function num(v, { min = 0, max = 1e9, int = true, name = 'number' } = {}) {
    if (v == null || v === '') fail('Missing ' + name + '.');
    const m = String(v).trim().match(/^(-?\d+(?:\.\d+)?)([kKmMbB]?)$/);
    if (!m) fail('"' + v + '" is not a valid ' + name + '. Try 500, 10k or 2.5m.');
    let n = parseFloat(m[1]) * ({ k: 1e3, m: 1e6, b: 1e9 }[m[2].toLowerCase()] || 1);
    if (int) n = Math.floor(n);
    if (n < min || n > max) fail(name + ' must be between ' + min + ' and ' + max + '.');
    return n;
  }
  function change(cur, mode, v) {
    mode = String(mode || '').toLowerCase();
    if (mode === 'add') return Math.min(1e9, cur + num(v));
    if (mode === 'remove') return Math.max(0, cur - num(v));
    if (mode === 'set') return num(v);
    return fail('Use add, remove or set.');
  }
  const findWeapon = q => {
    q = String(q || '').toLowerCase(); if (!q) fail('Missing weapon id. Type "weapons".');
    const all = FS.WEAPONS;
    const hit = all.find(w => w.id === q) || (all.filter(w => w.id.startsWith(q)).length === 1 && all.find(w => w.id.startsWith(q))) ||
      (all.filter(w => w.id.includes(q) || w.name.toLowerCase().includes(q)).length === 1 && all.find(w => w.id.includes(q) || w.name.toLowerCase().includes(q)));
    return hit || fail('No single weapon matches "' + q + '". Type "weapons".');
  };
  const totalXp = lvl => { let t = 0; for (let l = 1; l < lvl; l++) t += FS.xpForNext(l); return t; };
  const MODES = ['add', 'remove', 'set'];
  const wIds = extra => () => [...(extra || []), ...FS.WEAPONS.map(w => w.id)];
  const SPAWN_TYPES = () => [...Object.keys(FS.FRUITS), 'golden', 'bomb', 'random'];

  // ----- economy
  def('coins', 'economy', 'coins <add|remove|set> <n>', 'Change your coins (10k = 10,000).', a => { S().coins = change(S().coins, a[0], a[1]); FS.refresh(); return 'Coins = ' + fmt(S().coins); }, i => i === 0 ? MODES : null);
  def('tickets', 'economy', 'tickets <add|remove|set> <n>', 'Change your spin tickets.', a => { S().tickets = change(S().tickets, a[0], a[1]); FS.refresh(); return 'Tickets = ' + fmt(S().tickets); }, i => i === 0 ? MODES : null);
  def('xp', 'economy', 'xp <add|set> <n>', 'Add XP (level rewards apply) or set total XP.', a => {
    const m = String(a[0] || '').toLowerCase();
    if (m === 'add') FS.addXp(num(a[1], { min: 1 })); else if (m === 'set') S().xp = num(a[1]); else fail('Use add or set.');
    FS.refresh(); return 'Level ' + FS.levelInfo(S().xp).level + ' (' + fmt(S().xp) + ' XP)';
  }, i => i === 0 ? ['add', 'set'] : null);
  def('level', 'economy', 'level <n|+n>', 'Jump to a level, or go up n levels (no rewards).', a => {
    const cur = FS.levelInfo(S().xp).level, v = String(a[0] || '');
    const l = v.startsWith('+') ? cur + num(v.slice(1), { min: 1, max: 999, name: 'levels' }) : num(v, { min: 1, max: 999, name: 'level' });
    S().xp = totalXp(l); FS.refresh(); return 'Now level ' + l;
  });

  // ----- game pass
  const passXpFor = n => { let t = 0; for (let l = 1; l <= n; l++) t += FS.passNeed(l); return t; };
  def('gold', 'economy', 'gold <add|remove|set> <n>', 'Change your gold tickets (10 buy the Game Pass).', a => { S().gold = change(S().gold, a[0], a[1]); FS.refresh(); return 'Gold tickets = ' + fmt(S().gold); }, i => i === 0 ? MODES : null);
  def('pass', 'player', 'pass <give|remove|buy|status>', 'Give or remove the Game Pass, buy it with gold tickets, or see status.', a => {
    const s = S(), m = String(a[0] || 'status').toLowerCase();
    if (m === 'give') { s.pass = true; FS.refresh(); return 'Game Pass unlocked (free).'; }
    if (m === 'remove') { s.pass = false; s.passXp = 0; s.passDone = 0; FS.refresh(); return 'Game Pass removed.'; }
    if (m === 'buy') { if (s.pass) fail('You already own the pass.'); if (s.gold < FS.PASS_COST) fail('Needs ' + FS.PASS_COST + ' gold tickets, you have ' + s.gold + '.'); FS.buyPass(); return 'Bought the Game Pass.'; }
    if (m === 'status') return 'Pass ' + (s.pass ? 'owned' : 'not owned') + ', completed ' + FS.passInfo(s.passXp).done + ' / ' + FS.PASS_MAX + ', gold tickets ' + s.gold;
    return fail('Use give, remove, buy or status.');
  }, i => i === 0 ? ['give', 'remove', 'buy', 'status'] : null);
  def('passlevel', 'player', 'passlevel <n|+n>', 'Set completed pass levels 0-100 (no rewards), or go up n.', a => {
    const s = S(), v = String(a[0] || ''); if (!s.pass) fail('No pass yet. Type: pass give');
    const cur = FS.passInfo(s.passXp).done;
    const l = Math.min(FS.PASS_MAX, v.startsWith('+') ? cur + num(v.slice(1), { min: 1, max: 100, name: 'levels' }) : num(v, { min: 0, max: 100, name: 'level' }));
    s.passXp = passXpFor(l); s.passDone = l; FS.refresh(); return 'Pass levels completed = ' + l;
  });
  def('passxp', 'player', 'passxp add <n>', 'Add pass XP (pays rewards for every level it completes).', a => {
    if (!S().pass) fail('No pass yet. Type: pass give');
    if (a[0] !== 'add') fail('Use: passxp add <n>');
    FS.addPassXp(num(a[1], { min: 1 })); FS.refresh(); return 'Pass levels completed = ' + FS.passInfo(S().passXp).done;
  }, i => i === 0 ? ['add'] : null);
  def('maxpass', 'player', 'maxpass', 'Unlock the pass and finish all 100 levels with every reward (royal gold blade included).', () => {
    const s = S(); s.pass = true; s.passXp = passXpFor(FS.PASS_MAX); FS.grantPass(FS.PASS_MAX); FS.refresh();
    return 'Pass maxed. Royal gold blade unlocked.';
  });
  def('music', 'system', 'music [list|shuffle|n|id]', 'List the tracks, switch track by number or id, or shuffle them all.', a => {
    const T = FS.MUSIC_TRACKS, cur = S().track;
    if (!a[0] || a[0] === 'list') return { cls: 'info', html: '<b>0</b> shuffle all' + (cur === 'shuffle' ? ' <span class="g">(now)</span>' : '') + '\n' + T.map((t, i) => '<b>' + (i + 1) + '</b> ' + esc(t.name) + (t.id === cur ? ' <span class="g">(now)</span>' : '')).join('\n') };
    const q = String(a[0]).toLowerCase();
    if (q === 'shuffle' || q === '0') { FS.setTrack('shuffle'); return 'Music: shuffle all tracks'; }
    const t = /^\d+$/.test(q) ? T[+q - 1] : T.find(x => x.id.startsWith(q));
    if (!t) fail('No such track. Type: music list');
    FS.setTrack(t.id); return 'Music: ' + t.name;
  }, i => i === 0 ? ['list', 'shuffle', ...FS.MUSIC_TRACKS.map(t => t.id)] : null);
  def('passreward', 'player', 'passreward <n>', 'Pay out every pass reward up to level n (weapon at 100).', a => {
    if (!S().pass) fail('No pass yet. Type: pass give');
    FS.grantPass(num(a[0], { min: 1, max: 100, name: 'level' })); FS.refresh(); return 'Rewards paid up to level ' + S().passDone;
  });

  // ----- player
  def('stats', 'player', 'stats', 'Show your saved progress.', () => {
    const s = S(), li = FS.levelInfo(s.xp), r = FS.round();
    const row = (k, v) => '<span class="d">' + k.padEnd(12) + '</span> ' + esc(v);
    return { cls: 'info', html: [
      row('name', s.name), row('level', li.level + '  (' + fmt(s.xp) + ' XP, ' + li.into + '/' + li.need + ' to next)'),
      row('coins', fmt(s.coins)), row('tickets', fmt(s.tickets)), row('best score', fmt(s.best)),
      row('difficulty', s.difficulty), row('weapons', s.owned.length + '/' + FS.WEAPONS.length + '   equipped: ' + FS.weaponDef().id),
      row('round', r ? (r.paused ? 'paused' : 'live') + ' (score ' + r.score + ', lives ' + r.lives + ')' : 'none')
    ].join('\n') };
  });
  def('name', 'player', 'name <text>', 'Change your player name.', a => { S().name = FS.cleanName(a.join(' ')); FS.refresh(); return 'Name = ' + S().name; });
  def('difficulty', 'player', 'difficulty <easy|normal|hard>', 'Change difficulty.', a => {
    const d = String(a[0] || '').toLowerCase(); if (!FS.DIFFICULTY[d]) fail('Use easy, normal or hard.');
    S().difficulty = d; FS.refresh(); return 'Difficulty = ' + d;
  }, i => i === 0 ? Object.keys(FS.DIFFICULTY) : null);
  def('best', 'player', 'best reset', 'Reset your best score.', a => { if (a[0] !== 'reset') fail('Use: best reset'); S().best = 0; FS.refresh(); return 'Best score reset.'; }, i => i === 0 ? ['reset'] : null);
  def('scores', 'player', 'scores clear', 'Clear the leaderboard.', a => { if (a[0] !== 'clear') fail('Use: scores clear'); S().scores = []; FS.refresh(); return 'Leaderboard cleared.'; }, i => i === 0 ? ['clear'] : null);
  def('spin', 'player', 'spin reset', 'Make the free daily spin ready.', a => { if (a[0] !== 'reset') fail('Use: spin reset'); S().lastFree = 0; FS.refresh(); return 'Free spin is ready.'; }, i => i === 0 ? ['reset'] : null);

  // ----- weapons
  def('weapons', 'weapons', 'weapons', 'List every weapon and what you own.', () => ({ cls: 'info', html: FS.WEAPONS.map(w => {
    const own = FS.isOwned(w.id), eq = w.id === S().weapon;
    return (own ? '<span style="color:var(--ok)">[x]</span> ' : '<span class="d">[ ]</span> ') + '<b>' + esc(w.id.padEnd(22)) + '</b>' + esc(w.name) + (eq ? ' <span class="g">(equipped)</span>' : '') + (own ? '' : ' <span class="d">' + w.price + ' coins</span>');
  }).join('\n') }));
  def('unlock', 'weapons', 'unlock <id|all>', 'Give yourself a weapon (ids can be shortened).', a => {
    if (String(a[0]).toLowerCase() === 'all') { FS.WEAPONS.forEach(w => { if (!FS.isOwned(w.id)) S().owned.push(w.id); }); FS.refresh(); return 'All ' + FS.WEAPONS.length + ' weapons unlocked.'; }
    const w = findWeapon(a[0]); if (!FS.isOwned(w.id)) S().owned.push(w.id); FS.refresh(); return 'Unlocked ' + w.name + '.';
  }, i => i === 0 ? wIds(['all'])() : null);
  def('lock', 'weapons', 'lock <id|all>', 'Take a weapon away (free ones stay).', a => {
    const s = S();
    if (String(a[0]).toLowerCase() === 'all') s.owned = s.owned.filter(id => FS.WEAPONS.find(w => w.id === id).price === 0);
    else { const w = findWeapon(a[0]); if (w.price === 0) fail(w.name + ' is free and cannot be locked.'); s.owned = s.owned.filter(id => id !== w.id); }
    if (!FS.isOwned(s.weapon)) s.weapon = FS.DEFAULTS.weapon;
    FS.refresh(); return 'Done. Owned: ' + s.owned.length + '/' + FS.WEAPONS.length;
  }, i => i === 0 ? wIds(['all'])() : null);
  def('equip', 'weapons', 'equip <id>', 'Equip a weapon (unlocks it if needed).', a => {
    const w = findWeapon(a[0]); if (!FS.isOwned(w.id)) S().owned.push(w.id); S().weapon = w.id; FS.refresh(); return 'Equipped ' + w.name + '.';
  }, i => i === 0 ? wIds()() : null);

  // ----- round
  def('lives', 'round', 'lives <n|+n|full>', 'Set or add lives in the current round.', a => {
    const g = round(), v = String(a[0] || '');
    const n = v === 'full' ? g.maxLives : v.startsWith('+') ? g.lives + num(v.slice(1), { min: 1, max: 99, name: 'lives' }) : num(v, { min: 1, max: 99, name: 'lives' });
    FS.setLives(Math.min(99, n)); return 'Lives = ' + Math.min(99, n);
  }, i => i === 0 ? ['full'] : null);
  def('score', 'round', 'score <n>', 'Set the score of the current round.', a => { round(); const n = num(a[0], { name: 'score' }); FS.setScore(n); return 'Score = ' + fmt(n); });
  def('frenzy', 'round', 'frenzy', 'Start a frenzy (double points).', () => { round(); FS.frenzy(); return 'Frenzy!'; });
  def('spawn', 'round', 'spawn <type> [n]', 'Launch fruit, golden fruit or bombs.', a => {
    round(); const t = String(a[0] || 'random').toLowerCase(); if (!SPAWN_TYPES().includes(t)) fail('Types: ' + SPAWN_TYPES().join(', '));
    const n = a[1] ? num(a[1], { min: 1, max: 50, name: 'amount' }) : 1;
    for (let i = 0; i < n; i++) FS.spawn(t === 'random' ? Object.keys(FS.FRUITS)[(Math.random() * Object.keys(FS.FRUITS).length) | 0] : t, 1);
    return 'Spawned ' + n + ' x ' + t;
  }, i => i === 0 ? SPAWN_TYPES() : null);
  def('nuke', 'round', 'nuke', 'Slice every fruit on screen at once (bombs vanish).', () => { round(); FS.nuke(); return 'BOOM. Screen cleared.'; });
  def('purge', 'round', 'purge', 'Silently remove everything on screen.', () => { round(); FS.purge(); return 'Purged.'; });
  def('arena', 'round', 'arena <next|n>', 'Switch the arena (background).', a => {
    const g = FS.game; if (!g) fail(NEED_ROUND);
    if (!a[0]) return { cls: 'info', html: FS.BACKGROUNDS.map((b, i) => '<b>' + (i + 1) + '</b> ' + esc(b.name) + (i === g.bgIndex ? ' <span class="g">(now)</span>' : '')).join('\n') };
    const i = String(a[0]).toLowerCase() === 'next' ? g.bgIndex + 1 : num(a[0], { min: 1, max: FS.BACKGROUNDS.length, name: 'arena' }) - 1;
    FS.setArena(i); return 'Arena: ' + FS.BACKGROUNDS[g.bgIndex].name;
  }, i => i === 0 ? ['next', ...FS.BACKGROUNDS.map((b, k) => String(k + 1))] : null);

  // ----- cheats
  const flag = (name, key, label, desc) => def(name, 'cheats', name + ' [on|off]', desc, a => {
    const v = String(a[0] || 'toggle').toLowerCase();
    cheats[key] = v === 'on' ? true : v === 'off' ? false : !cheats[key];
    renderCheats(); return label + ' ' + (cheats[key] ? 'ENABLED' : 'disabled');
  }, i => i === 0 ? ['on', 'off', 'toggle'] : null);
  flag('god', 'god', 'God mode', 'Never lose a life.');
  flag('auto', 'auto', 'Auto-slice', 'Cut every fruit automatically.');
  flag('nobombs', 'noBombs', 'No bombs', 'Stop bombs from spawning.');
  flag('freeze', 'freeze', 'Freeze time', 'Freeze fruit and spawning.');
  def('mult', 'cheats', 'mult <1-100>', 'Multiply score and coins from fruit.', a => { cheats.mult = num(a[0], { min: 1, max: 100, name: 'multiplier' }); renderCheats(); return 'Multiplier = x' + cheats.mult; }, i => i === 0 ? ['1', '2', '5', '10', '50'] : null);
  def('speed', 'cheats', 'speed <0.1-3>', 'Game time scale (0.5 = slow-mo).', a => { cheats.speed = num(a[0], { min: 0.1, max: 3, int: false, name: 'speed' }); renderCheats(); return 'Time scale = ' + cheats.speed + 'x'; }, i => i === 0 ? ['0.25', '0.5', '1', '1.5', '2'] : null);
  def('rate', 'cheats', 'rate <0.25-6>', 'How fast fruit spawns.', a => { cheats.rate = num(a[0], { min: 0.25, max: 6, int: false, name: 'rate' }); renderCheats(); return 'Spawn rate = ' + cheats.rate + 'x'; }, i => i === 0 ? ['0.5', '1', '2', '4'] : null);
  def('cheats', 'cheats', 'cheats [off]', 'Show active cheats, or disable them all.', a => {
    if (String(a[0] || '').toLowerCase() === 'off') { Object.assign(cheats, { god: false, auto: false, noBombs: false, freeze: false, mult: 1, speed: 1, rate: 1 }); renderCheats(); return 'All cheats disabled.'; }
    const on = (v, t) => (v ? '<span style="color:var(--ok)">[on] </span>' : '<span class="d">[off]</span>') + ' ' + t;
    return { cls: 'info', html: [on(cheats.god, 'god'), on(cheats.auto, 'auto'), on(cheats.noBombs, 'nobombs'), on(cheats.freeze, 'freeze'),
      on(cheats.mult !== 1, 'mult   x' + cheats.mult), on(cheats.speed !== 1, 'speed  ' + cheats.speed + 'x'), on(cheats.rate !== 1, 'rate   ' + cheats.rate + 'x')].join('\n') };
  }, i => i === 0 ? ['off'] : null);

  // ----- system
  def('help', 'system', 'help [command]', 'List commands, or explain one.', a => {
    if (a[0]) { const c = C[resolve(a[0])]; if (!c) fail('Unknown command "' + a[0] + '".'); return { cls: 'info', html: '<b>' + esc(c.usage) + '</b>\n  ' + esc(c.desc) }; }
    const w = Math.max(...Object.values(C).map(c => c.usage.length)) + 2;
    return { cls: 'info', html: GROUPS.map(g => '<span class="g">' + g.toUpperCase() + '</span>\n' + Object.values(C).filter(c => c.group === g).map(c => '  <b>' + esc(c.usage.padEnd(w)) + '</b><span class="d">' + esc(c.desc) + '</span>').join('\n')).join('\n') +
      '\n\n<span class="d">Tab completes, Up/Down recalls history. Numbers accept k and m (10k, 2.5m).</span>' };
  }, i => i === 0 ? Object.keys(C) : null);
  def('theme', 'system', 'theme [' + THEMES.join('|') + ']', 'Change the console color theme.', a => {
    const t = (a[0] || THEMES[(THEMES.indexOf(root.dataset.theme) + 1) % THEMES.length]).toLowerCase(); if (!THEMES.includes(t)) fail('Themes: ' + THEMES.join(', '));
    setTheme(t); return 'Theme = ' + t;
  }, i => i === 0 ? THEMES : null);
  def('matrix', 'system', 'matrix [on|off]', 'Toggle the matrix rain behind the terminal.', a => {
    const on = a[0] ? a[0] === 'on' : !rains.term; const cv = $('#adm-rain2'); cv.classList.toggle('on', on);
    if (on) startRain('term', cv); else stopRain('term'); return 'Matrix ' + (on ? 'ON' : 'off');
  }, i => i === 0 ? ['on', 'off'] : null);
  def('clear', 'system', 'clear', 'Clear the terminal.', () => { logEl.innerHTML = ''; return null; });
  def('history', 'system', 'history', 'Commands you typed this session.', () => st.hist.length ? { cls: 'info', html: st.hist.map((h, i) => '<span class="d">' + String(i + 1).padStart(3) + '</span>  ' + esc(h)).join('\n') } : 'Nothing yet.');
  def('log', 'system', 'log [n]', 'Audit log of admin actions (saved on this device).', a => {
    const n = a[0] ? num(a[0], { min: 1, max: 100, name: 'count' }) : 15, list = audit.slice(-n);
    return list.length ? { cls: 'info', html: list.map(e => '<span class="d">' + new Date(e.t).toLocaleString() + '</span>  ' + esc(e.x)).join('\n') } : 'Audit log is empty.';
  });
  def('whoami', 'system', 'whoami', 'Who are you?', () => 'root@fruit-slash (admin, PIN verified)');
  def('echo', 'system', 'echo <text>', 'Print text.', a => a.join(' '));
  def('sudo', 'system', 'sudo <cmd>', 'You are already root.', a => { if (!a.length) return 'Nice try. You are already root.'; const r = exec(a.join(' ')); if (!r.ok) fail(r.msg); return r.html ? { html: r.html, cls: r.cls } : (r.msg || null); });
  def('banner', 'system', 'banner', 'Show the logo.', () => { banner(); return null; });
  def('export', 'system', 'export', 'Copy your save data to the clipboard.', () => {
    const json = JSON.stringify(S());
    (navigator.clipboard ? navigator.clipboard.writeText(json) : Promise.reject()).then(() => print('Save copied (' + json.length + ' bytes). Restore with: import <json>', 'ok'), () => { print('Clipboard blocked. Copy this save by hand:', 'warn'); print(json, 'dim'); });
    return 'Copying save...';
  });
  def('import', 'system', 'import <json>', 'Restore a save made with export.', a => {
    let o; try { o = JSON.parse(a.join(' ')); } catch (e) { fail('That is not valid JSON.'); }
    if (!o || typeof o !== 'object' || Array.isArray(o)) fail('Expected a save object.');
    const s = S(); Object.keys(FS.DEFAULTS).forEach(k => { if (k in o && typeof o[k] === typeof FS.DEFAULTS[k]) s[k] = o[k]; });
    s.owned = (Array.isArray(s.owned) ? s.owned : []).filter(id => FS.WEAPONS.some(w => w.id === id));
    FS.WEAPONS.forEach(w => { if (w.price === 0 && !s.owned.includes(w.id)) s.owned.push(w.id); });
    if (!s.owned.includes(s.weapon)) s.weapon = FS.DEFAULTS.weapon;
    ['coins', 'xp', 'tickets', 'best'].forEach(k => { s[k] = Math.max(0, Math.floor(+s[k] || 0)); });
    if (!FS.DIFFICULTY[s.difficulty]) s.difficulty = FS.DEFAULTS.difficulty;
    s.name = FS.cleanName(s.name); FS.refresh(); return 'Save imported.';
  });
  def('reset', 'system', 'reset all confirm', 'Wipe ALL saved progress.', a => {
    if (a[0] !== 'all' || a[1] !== 'confirm') fail('This erases everything. Type: reset all confirm');
    Object.assign(S(), JSON.parse(JSON.stringify(FS.DEFAULTS))); FS.refresh(); return 'All progress reset.';
  }, i => i === 0 ? ['all'] : i === 1 ? ['confirm'] : null);
  def('logout', 'system', 'logout', 'Lock the console and disable all cheats.', () => {
    Object.assign(cheats, { god: false, auto: false, noBombs: false, freeze: false, mult: 1, speed: 1, rate: 1 });
    st.authed = false; st.booted = false; logEl.innerHTML = ''; renderChips(); closeConsole(); return null;
  });
  def('exit', 'system', 'exit', 'Close the console.', () => { closeConsole(); return null; });

  function exec(text, noAudit) {
    const parts = text.trim().split(/\s+/), raw = parts.shift(), name = resolve(raw);
    if (!name) return { ok: false, msg: 'Unknown command "' + raw + '". Type help.' };
    try {
      const r = C[name].run(parts);
      if (!noAudit && !READONLY.has(name) && !(name === 'cheats' && !parts.length)) addAudit(text.trim());
      $('#f-last').textContent = text.trim().slice(0, 28);
      if (r == null) return { ok: true, silent: true };
      if (typeof r === 'string') return { ok: true, msg: r };
      return { ok: true, html: r.html, cls: r.cls || 'ok', msg: strip(r.html).split('\n')[0] };
    } catch (e) { return { ok: false, msg: e.message }; }
  }
  function show(r) {
    if (r.silent) return;
    if (!r.ok) { print(r.msg, 'err'); return; }
    if (r.html) line(r.html, r.cls); else print(r.msg, 'ok');
  }
  function runTerminal(text) {
    st.hist.push(text); st.hi = st.hist.length;
    line('<b>&rsaquo;</b> ' + esc(text), 'in');
    const r = exec(text); show(r); r.ok ? sfx.ok() : sfx.err();
    renderAll(true);
  }
  function runUI(text, quiet) {      // used by dashboard / weapons / cheats buttons
    const r = exec(text, quiet);
    if (!quiet) { line('<span class="d">ui &rsaquo; ' + esc(text) + '</span>', 'dim'); show(r); if (!r.silent) toast(r.msg, !r.ok); }
    r.ok ? sfx.ok() : sfx.err();
    renderAll(true); return r;
  }

  /* ---------- autocomplete ---------- */
  function cand(v) {
    const endsSpace = /\s$/.test(v), parts = v.trimStart().split(/\s+/); if (endsSpace) parts.push('');
    const idx = parts.length - 1, cur = parts[idx].toLowerCase(); let pool = [];
    if (idx === 0) pool = [...Object.keys(C), ...Object.keys(ALIAS)];
    else { const c = C[resolve(parts[0])]; const r = c && c.comp ? c.comp(idx - 1, parts.slice(1, idx)) : null; pool = r || []; }
    return { parts, cur, list: pool.filter(p => p.toLowerCase().startsWith(cur) && p.toLowerCase() !== cur) };
  }
  function updateGhost() {
    const v = inp.value; let rest = '';
    if (!v) rest = "type 'help' (Tab completes)"; else { const c = cand(v); if (c.list.length) rest = c.list[0].slice(c.cur.length); }
    ghost.innerHTML = '<span>' + esc(v) + '</span><em>' + esc(rest) + '</em>';
  }
  function tabComplete() {
    const v = inp.value, c = cand(v); if (!c.list.length) return;
    let pre = c.list[0]; c.list.forEach(p => { while (!p.toLowerCase().startsWith(pre.toLowerCase())) pre = pre.slice(0, -1); });
    const head = v.slice(0, v.length - c.cur.length);
    if (c.list.length === 1) inp.value = head + c.list[0] + ' ';
    else if (pre.length > c.cur.length) inp.value = head + pre;
    else print(c.list.join('   '), 'dim');
    updateGhost();
  }
  inp.addEventListener('input', () => { updateGhost(); sfx.key(); });
  inp.addEventListener('keydown', e => {
    if (e.key === 'Tab') { e.preventDefault(); tabComplete(); }
    else if (e.key === 'ArrowUp' && st.hist.length) { e.preventDefault(); st.hi = Math.max(0, st.hi - 1); inp.value = st.hist[st.hi]; updateGhost(); }
    else if (e.key === 'ArrowDown' && st.hist.length) { e.preventDefault(); st.hi = Math.min(st.hist.length, st.hi + 1); inp.value = st.hist[st.hi] || ''; updateGhost(); }
    else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); logEl.innerHTML = ''; }
  });
  $('#adm-form').addEventListener('submit', e => { e.preventDefault(); const v = inp.value.trim(); inp.value = ''; updateGhost(); if (v) runTerminal(v); });
  $('#adm-quick').addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { runTerminal(b.dataset.q); inp.focus(); } });

  /* =====================================================
     Panels: dashboard, weapons, cheats
  ===================================================== */
  function setNum(el, n) {
    n = Math.round(n);
    if (el.dataset.v === undefined) { el.dataset.v = n; el.textContent = fmt(n); return; }
    const from = +el.dataset.v; if (from === n) return;
    el.dataset.v = n; cancelAnimationFrame(el._raf);
    const t0 = performance.now(), dur = 450;
    const step = t => { const k = Math.min(1, (t - t0) / dur); el.textContent = fmt(from + (n - from) * (1 - Math.pow(1 - k, 3))); if (k < 1) el._raf = requestAnimationFrame(step); };
    el._raf = requestAnimationFrame(step);
  }
  const B = k => $('[data-b="' + k + '"]', root);
  function renderDash() {
    const s = S(), li = FS.levelInfo(s.xp), g = FS.round();
    setNum($('[data-n="coins"]', root), s.coins); setNum($('[data-n="tickets"]', root), s.tickets);
    B('level').textContent = li.level; B('xptext').textContent = li.into + ' / ' + li.need + ' XP';
    B('xpbar').style.width = (li.into / li.need * 100).toFixed(1) + '%'; B('xptag').textContent = fmt(s.xp) + ' TOTAL';
    const tags = [B('rtag'), B('rtag2'), B('rtag3')], label = g ? (g.paused ? 'PAUSED' : 'LIVE') : 'NO ROUND';
    tags.forEach(t => { t.textContent = label; t.className = 'tag ' + (g ? 'live' : 'off'); });
    B('score').textContent = g ? fmt(g.score) : '--';
    B('lives').innerHTML = g ? '&#9829;'.repeat(Math.min(g.lives, 12)) + '<span class="x">' + '&#9829;'.repeat(Math.max(0, Math.min(g.maxLives, 12) - g.lives)) + '</span>' : '--';
    B('time').textContent = g ? Math.floor(g.time / 60) + ':' + pad2(Math.floor(g.time % 60)) : '--';
    B('fruit').textContent = g ? g.fruits.length : '--'; B('rhint').hidden = !!g;
    B('best').textContent = fmt(s.best); B('owned').textContent = s.owned.length + '/' + FS.WEAPONS.length;
    ['easy', 'normal', 'hard'].forEach(d => B('diff-' + d).setAttribute('aria-checked', String(s.difficulty === d)));
    const nm = $('#d-name', root); if (document.activeElement !== nm) nm.value = s.name;
  }
  const art = w => w.frames
    ? '<span class="adm-sbox"><span class="adm-sprite' + (w.pixel ? ' px' : '') + '" style="--fw:' + w.fw + 'px;--fh:' + w.fh + 'px;--n:' + w.frames + ';--dur:' + (w.frames / w.fps).toFixed(2) + 's;--s:' + (60 / Math.max(w.fw, w.fh)).toFixed(3) + ';background-image:url(\'' + w.img + '\')"></span></span>'
    : '<span class="adm-sbox"><img class="' + (w.pixel ? 'px' : '') + '" src="' + w.img + '" alt=""></span>';
  function renderWeapons() {
    const q = st.wq.toLowerCase(), s = S();
    $('#adm-wgrid').innerHTML = FS.WEAPONS.filter(w => !q || w.id.includes(q) || w.name.toLowerCase().includes(q)).map(w => {
      const own = FS.isOwned(w.id), eq = w.id === s.weapon;
      return '<div class="adm-w' + (own ? ' own' : ' lk') + (eq ? ' eq' : '') + '">' + '<span class="st">' + (eq ? 'EQUIPPED' : own ? 'OWNED' : 'LOCKED') + '</span>' + art(w) +
        '<b>' + esc(w.name) + '</b><small>' + esc(w.id) + (own ? '' : ' / ' + w.price + ' coins') + '</small><div class="adm-row">' +
        (eq ? '' : '<button class="adm-btn" data-do="equip ' + w.id + '">EQUIP</button>') +
        (own ? (w.price === 0 ? '' : '<button class="adm-btn danger" data-do="lock ' + w.id + '">LOCK</button>') : '<button class="adm-btn warn" data-do="unlock ' + w.id + '">UNLOCK</button>') + '</div></div>';
    }).join('') || '<p class="adm-sub">No weapons match.</p>';
  }
  function buildSpawner() {
    $('#adm-spawn').innerHTML = Object.keys(FS.FRUITS).map(k => '<button type="button" data-round data-do="spawn ' + k + ' {spawnN}"><img src="' + FS.FRUITS[k].src + '" alt="">' + k + '</button>').join('') +
      '<button type="button" data-round data-do="spawn golden {spawnN}"><span class="em">&#11088;</span>golden</button>' +
      '<button type="button" data-round data-do="spawn bomb {spawnN}"><span class="em">&#128163;</span>bomb</button>' +
      '<button type="button" data-round data-do="spawn random {spawnN}"><span class="em">&#127922;</span>random</button>';
  }
  function renderCheats() {
    $$('[data-sw]', root).forEach(b => b.setAttribute('aria-checked', String(!!cheats[b.dataset.sw])));
    $$('[data-mult]', root).forEach(b => b.setAttribute('aria-checked', String(+b.dataset.mult === cheats.mult)));
    $$('[data-sn]', root).forEach(b => b.setAttribute('aria-checked', String(+b.dataset.sn === st.spawnN)));
    ['speed', 'rate'].forEach(k => { const r = $('[data-slide="' + k + '"]', root); if (document.activeElement !== r) r.value = cheats[k]; $('[data-out="' + k + '"]', root).textContent = cheats[k] + 'x'; });
    const n = countCheats(); $('#c-count').textContent = n + ' ACTIVE'; $('#f-cheats').textContent = n;
    const has = !!FS.round(); $$('[data-round]', root).forEach(b => { b.disabled = !has; });
    $('#c-note').textContent = has ? 'Round active. These act on the current round when you close the console.' : 'Start a round (Play) to use round actions.';
    renderChips();
  }
  const countCheats = () => [cheats.god, cheats.auto, cheats.noBombs, cheats.freeze, cheats.mult !== 1, cheats.speed !== 1, cheats.rate !== 1].filter(Boolean).length;
  function renderChips() {
    const c = [];
    if (cheats.god) c.push('GOD'); if (cheats.auto) c.push('AUTO-SLICE'); if (cheats.noBombs) c.push('NO BOMBS'); if (cheats.freeze) c.push('FROZEN');
    if (cheats.mult !== 1) c.push('x' + cheats.mult + ' SCORE'); if (cheats.speed !== 1) c.push(cheats.speed + 'x TIME'); if (cheats.rate !== 1) c.push(cheats.rate + 'x SPAWN');
    chipsEl.innerHTML = c.map(t => '<span>' + t + '</span>').join('');
  }
  function renderFoot() {
    const g = FS.round(); $('#f-round').textContent = g ? (g.paused ? 'paused' : 'live') : 'none';
    $('#f-scene').textContent = FS.game ? 'in game' : 'menu'; $('#f-theme').textContent = root.dataset.theme;
  }
  function renderAll(force) {
    if (!st.authed) return;
    renderFoot(); renderCheats();
    if (force || st.tab === 'dashboard') renderDash();
    if (force && st.tab === 'weapons') renderWeapons();
  }
  function live() { if (st.authed && st.open) { renderFoot(); if (st.tab === 'dashboard') renderDash(); $$('[data-round]', root).forEach(b => { b.disabled = !FS.round(); }); } }

  // ----- clicks on dashboard / weapons / cheats controls
  let confirmT = 0;
  root.addEventListener('click', e => {
    const sn = e.target.closest('[data-sn]'); if (sn) { st.spawnN = +sn.dataset.sn; renderCheats(); sfx.tab(); return; }
    const b = e.target.closest('[data-do]'); if (!b || b.disabled || b.tagName === 'INPUT') return;
    if (b.hasAttribute('data-confirm')) {
      if (!b.classList.contains('hot')) { b.classList.add('hot'); b.dataset.t = b.textContent; b.textContent = 'CLICK AGAIN'; clearTimeout(confirmT); confirmT = setTimeout(() => { b.classList.remove('hot'); b.textContent = b.dataset.t; }, 3000); sfx.tab(); return; }
      b.classList.remove('hot'); b.textContent = b.dataset.t;
    }
    runUI(b.dataset.do.replace(/\{([\w-]+)\}/g, (_, id) => id === 'spawnN' ? st.spawnN : ($('#' + id, root) || {}).value || ''));
  });
  root.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.matches('input[data-do]')) { e.preventDefault(); runUI(e.target.dataset.do.replace(/\{([\w-]+)\}/g, (_, id) => ($('#' + id, root) || {}).value || '')); }
  });
  root.addEventListener('input', e => {
    if (e.target.id === 'w-q') { st.wq = e.target.value; renderWeapons(); }
    const sl = e.target.dataset && e.target.dataset.slide; if (sl) { runUI(sl + ' ' + e.target.value, true); }
  });
  root.addEventListener('change', e => { const sl = e.target.dataset && e.target.dataset.slide; if (sl) { addAudit(sl + ' ' + e.target.value); toast(sl + ' = ' + e.target.value + 'x'); } });

  /* =====================================================
     Toast, tabs, theme
  ===================================================== */
  let toastT = 0;
  function toast(msg, bad) {
    if (!msg) return; toastEl.textContent = msg; toastEl.classList.toggle('err', !!bad); toastEl.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), 1800);
  }
  function setTab(name) {
    st.tab = name;
    $$('.adm-tabs button', root).forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
    $$('.adm-panel', root).forEach(p => p.classList.toggle('active', p.dataset.panel === name));
    if (name === 'dashboard') renderDash(); if (name === 'weapons') renderWeapons(); if (name === 'cheats') renderCheats();
    if (name === 'terminal') setTimeout(() => inp.focus(), 30);
    if (name === 'terminal' && rains.term === undefined && $('#adm-rain2').classList.contains('on')) startRain('term', $('#adm-rain2'));
  }
  $('.adm-tabs', root).addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (b) { setTab(b.dataset.tab); sfx.tab(); } });
  function setTheme(t) { root.dataset.theme = t; ls.set(THEME_KEY, t); $('#f-theme').textContent = t; if (rains.gate && !gate.hidden) startRain('gate', $('#adm-rain')); drawSpark(); }
  $('#adm-theme').addEventListener('click', () => { setTheme(THEMES[(THEMES.indexOf(root.dataset.theme) + 1) % THEMES.length]); sfx.tab(); });

  /* =====================================================
     PIN gate
  ===================================================== */
  const lockLeft = () => Math.max(0, (+ls.get(LOCK_KEY) || 0) - Date.now());
  let gateT = 0;
  function renderDots() { dots.innerHTML = '<i></i>'.repeat(Math.min(pin.value.length, 24)) + '<span class="caret"></span>'; }
  function gateTick() {
    const left = lockLeft();
    if (left > 0) { gmsg.textContent = 'LOCKED OUT. RETRY IN ' + Math.ceil(left / 1000) + 's'; go.disabled = true; pin.disabled = true; }
    else if (go.disabled) { go.disabled = false; pin.disabled = false; gmsg.textContent = ''; pin.focus(); }
  }
  function showGate() {
    gate.hidden = false; main.hidden = true; pill.textContent = 'LOCKED'; pill.classList.remove('on');
    pin.value = ''; renderDots(); gmsg.textContent = ''; granted.hidden = true;
    startRain('gate', $('#adm-rain')); clearInterval(gateT); gateT = setInterval(gateTick, 500); gateTick();
    setTimeout(() => pin.focus(), 60);
  }
  function showMain() {
    clearInterval(gateT); stopRain('gate'); gate.hidden = true; main.hidden = false; pill.textContent = 'ADMIN'; pill.classList.add('on');
    setTab(st.tab); renderAll(true); buildSpawner(); renderCheats(); updateGhost();
  }
  async function attempt() {
    const left = lockLeft(); if (left > 0) { gateTick(); return; }
    if (hashPin(pin.value.trim().toUpperCase()) === HASH) {
      st.authed = true; st.fails = 0; sfx.grant(); granted.hidden = false; go.disabled = true;
      await sleep(950); go.disabled = false; granted.hidden = true; showMain();
      if (!st.booted) boot(); else inp.focus();
    } else {
      st.fails++; pin.value = ''; renderDots(); sfx.err();
      win.classList.remove('shake', 'flash-err'); void win.offsetWidth; win.classList.add('shake', 'flash-err');
      if (st.fails >= 3) { st.fails = 0; ls.set(LOCK_KEY, String(Date.now() + 30000)); gateTick(); }
      else gmsg.textContent = 'ACCESS DENIED  (' + st.fails + '/3)';
    }
  }
  pin.addEventListener('input', () => { renderDots(); sfx.key(); if (!lockLeft()) gmsg.textContent = ''; });
  pin.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); attempt(); } });
  go.addEventListener('click', attempt);
  $('.adm-pinbox', root).addEventListener('click', () => pin.focus());

  /* ---------- boot sequence ---------- */
  function banner() {
    ['╔═╗╔╦╗╔╦╗╦╔╗╔   ╔═╗╔═╗╦═╗╔═╗', '╠═╣ ║║║║║║║║║   ║  ║ ║╠╦╝║╣ ', '╩ ╩═╩╝╩ ╩╩╝╚╝   ╚═╝╚═╝╩╚═╚═╝'].forEach(l => print(l, 'art'));
  }
  async function boot() {
    st.booted = true; logEl.innerHTML = ''; banner(); sfx.open();
    for (const s of ['auth token verified', 'mounting save data', 'hooking round controller', 'arming cheat engine', 'syncing weapon registry (' + FS.WEAPONS.length + ' blades)']) {
      line('[ <b>OK</b> ] ' + esc(s), 'dim'); sfx.key(); await sleep(120);
    }
    await typeLine('Welcome back, ' + S().name + '. Type help, press Tab, or use the tabs above.', 'ok', 14);
    inp.focus();
  }

  /* =====================================================
     Open / close + global keys
  ===================================================== */
  function openConsole() {
    if (st.open) return;
    st.open = true; root.hidden = false; st.pausedByMe = FS.pause();
    win.classList.remove('shake', 'flash-err'); win.style.animation = 'none'; void win.offsetWidth; win.style.animation = '';
    sfx.open(); startFx(); drawSpark();
    if (st.authed) showMain(); else showGate();
    renderChips();
  }
  function closeConsole() {
    if (!st.open) return;
    st.open = false; root.hidden = true; stopFx(); clearInterval(gateT);
    if (st.pausedByMe) { st.pausedByMe = false; FS.resume(); }
  }
  openBtn.addEventListener('click', openConsole);
  $('#adm-x').addEventListener('click', closeConsole);
  root.addEventListener('pointerdown', e => { if (e.target === root) closeConsole(); });
  window.addEventListener('keydown', e => {
    const t = e.target, inField = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT');
    if (e.key === '`' || e.key === '~') {
      if (inField && !root.contains(t)) return;          // typing a name somewhere else in the game
      e.preventDefault(); e.stopImmediatePropagation(); st.open ? closeConsole() : openConsole(); return;
    }
    if (!st.open) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); closeConsole(); return; }
    if (e.altKey && /^[1-4]$/.test(e.key) && st.authed) { e.preventDefault(); setTab(['terminal', 'dashboard', 'weapons', 'cheats'][+e.key - 1]); sfx.tab(); return; }
    if (!inField && (e.key === 'p' || e.key === 'P')) e.stopImmediatePropagation();   // keep the game from resuming under the console
  }, true);

  renderChips();
})();
