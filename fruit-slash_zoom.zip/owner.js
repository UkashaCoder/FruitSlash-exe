/* =====================================================================
   OWNER console  -  adds an OWNER tab to ADMIN//CORE (same PIN gate)
   - every player id that has played on this device (the "roster")
   - view / edit all player data, block or unblock a player id
   - change, regenerate or assign a player id
   - switch the active player, create a new player
   - export / import player data (file or copy-paste player code)

   Note: this is a browser game with no server. The roster holds the
   players who used THIS device, plus any players you import from a
   player code or export file. It is not a live list of other phones.
===================================================================== */
(function () {
  'use strict';
  const FS = window.FS_ADMIN, root = document.getElementById('adm-root');
  if (!FS || !root || !FS.ROSTER_KEY) return;

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = v => Math.max(0, Math.min(1e9, Math.floor(+v || 0)));
  const fmt = n => num(n).toLocaleString('en-US');
  const LOG_KEY = 'fruitSlash.ownerLog';
  const CODE_PREFIX = 'FSP1.';
  const MAX_IMPORT = 500;

  /* ---------- storage helpers ---------- */
  const readRoster = () => {
    try { const r = JSON.parse(localStorage.getItem(FS.ROSTER_KEY) || '{}'); return r && typeof r === 'object' && !Array.isArray(r) ? r : {}; }
    catch (e) { return {}; }
  };
  const writeRoster = r => { try { localStorage.setItem(FS.ROSTER_KEY, JSON.stringify(r)); return true; } catch (e) { return false; } };
  const activePid = () => FS.settings.pid;
  const lvl = p => { try { return FS.levelInfo(num(p.xp)).level; } catch (e) { return 1; } };
  let log = []; try { log = JSON.parse(localStorage.getItem(LOG_KEY) || '[]'); if (!Array.isArray(log)) log = []; } catch (e) { log = []; }
  const addLog = x => { log.push({ t: Date.now(), x }); if (log.length > 40) log.shift(); try { localStorage.setItem(LOG_KEY, JSON.stringify(log)); } catch (e) { /* ignore */ } };
  const when = t => t ? new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'never';

  /* only known save fields are accepted from imports (also blocks odd keys like __proto__) */
  function clean(o) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
    const out = {}, D = FS.DEFAULTS;
    Object.keys(D).forEach(k => {
      if (!Object.prototype.hasOwnProperty.call(o, k)) return;
      const v = o[k];
      if (Array.isArray(D[k])) { if (Array.isArray(v)) out[k] = JSON.parse(JSON.stringify(v.slice(0, 100))); }
      else if (k === 'pending') { if (v === null || typeof v === 'number') out[k] = v; }
      else if (typeof v === typeof D[k]) out[k] = v;
    });
    out.pid = String(out.pid || '').toUpperCase();
    return FS.PID_RE.test(out.pid) ? out : null;
  }

  /* ---------- build the tab ---------- */
  const tabs = $('.adm-tabs', root), panels = $('.adm-panels', root);
  const tabBtn = document.createElement('button');
  tabBtn.type = 'button'; tabBtn.setAttribute('role', 'tab'); tabBtn.dataset.tab = 'owner';
  tabBtn.innerHTML = 'OWNER<kbd>Alt 5</kbd>';
  tabs.appendChild(tabBtn);

  const panel = document.createElement('div');
  panel.className = 'adm-panel own'; panel.dataset.panel = 'owner';
  panel.innerHTML = `
    <div class="own-sum" id="own-sum"></div>
    <div class="own-bar">
      <input class="adm-in own-search" id="own-q" placeholder="Search id, name or note" autocomplete="off" spellcheck="false">
      <button class="adm-btn own-f on" data-act="filter" data-f="all">ALL</button>
      <button class="adm-btn own-f" data-act="filter" data-f="banned">BANNED</button>
      <button class="adm-btn" data-act="new" title="Create a fresh player with a new id and switch to it">+ NEW PLAYER</button>
      <button class="adm-btn" data-act="export-all">EXPORT ALL</button>
      <button class="adm-btn" data-act="toggle-import">IMPORT</button>
      <button class="adm-btn warn" data-act="unban-all">UNBAN ALL</button>
    </div>
    <div class="own-import" id="own-import" hidden>
      <textarea class="adm-in" id="own-code" rows="3" placeholder="Paste player codes (one per line) or an export JSON here" spellcheck="false"></textarea>
      <div class="adm-row">
        <input type="file" id="own-file" accept=".json,.txt,application/json,text/plain" hidden>
        <button class="adm-btn" data-act="pick-file">CHOOSE FILE</button>
        <label class="own-chk"><input type="checkbox" id="own-over"> overwrite players that already exist</label>
        <button class="adm-btn big own-go" data-act="import">IMPORT PLAYERS</button>
      </div>
    </div>
    <div class="own-cols">
      <div class="adm-card own-listcard"><h3>ALL PLAYERS<span class="tag" id="own-count">0</span></h3><div class="own-list" id="own-list"></div></div>
      <div class="adm-card own-detailcard"><h3>PLAYER DATA<span class="tag" id="own-tag">-</span></h3><div id="own-detail"></div></div>
    </div>
    <div class="adm-card own-logcard"><h3>OWNER LOG</h3><div class="own-log" id="own-log"></div></div>`;
  panels.appendChild(panel);

  const toastEl = $('#adm-toast');
  let toastT = 0;
  function toast(msg, bad) {
    if (!toastEl) return;
    toastEl.textContent = msg; toastEl.classList.toggle('err', !!bad); toastEl.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), 2200);
  }

  /* ---------- state + render ---------- */
  const st = { sel: null, q: '', f: 'all' };
  function sortedPlayers() {
    const r = readRoster(), q = st.q.trim().toLowerCase();
    return Object.keys(r).map(k => r[k]).filter(p => p && FS.PID_RE.test(String(p.pid || '')))
      .filter(p => st.f === 'all' || p.banned)
      .filter(p => !q || String(p.pid).toLowerCase().includes(q) || String(p.name || '').toLowerCase().includes(q) || String(p.note || '').toLowerCase().includes(q))
      .sort((a, b) => (b.pid === activePid()) - (a.pid === activePid()) || (+b.lastSeen || 0) - (+a.lastSeen || 0));
  }
  function renderSummary() {
    const r = readRoster(), all = Object.keys(r).map(k => r[k]).filter(Boolean);
    const banned = all.filter(p => p.banned).length;
    const coins = all.reduce((a, p) => a + num(p.coins), 0);
    const top = all.reduce((a, p) => Math.max(a, lvl(p)), 1);
    const best = all.reduce((a, p) => Math.max(a, num(p.best)), 0);
    $('#own-sum').innerHTML = [
      ['PLAYERS', fmt(all.length)], ['BANNED', fmt(banned)], ['TOTAL COINS', fmt(coins)], ['TOP LEVEL', fmt(top)], ['TOP SCORE', fmt(best)]
    ].map(a => `<div class="own-stat"><small>${a[0]}</small><b>${a[1]}</b></div>`).join('');
  }
  function renderList() {
    const list = sortedPlayers();
    $('#own-count').textContent = list.length;
    $('#own-list').innerHTML = list.length ? list.map(p => `
      <button type="button" class="own-row${p.pid === st.sel ? ' sel' : ''}${p.banned ? ' ban' : ''}" data-pid="${esc(p.pid)}">
        <span class="own-id">${esc(p.pid)}${p.pid === activePid() ? '<em>ACTIVE</em>' : ''}${p.banned ? '<em class="b">BANNED</em>' : ''}</span>
        <span class="own-nm">${esc(p.name || 'Player')}</span>
        <span class="own-mt">Lv ${lvl(p)} &middot; ${fmt(p.coins)} coins &middot; best ${fmt(p.best)}${p.banned && p.banReason ? ' &middot; ' + esc(p.banReason) : ''}</span>
      </button>`).join('') : '<p class="own-empty">No players match.</p>';
  }
  function renderDetail() {
    const r = readRoster(), p = st.sel && r[st.sel];
    const box = $('#own-detail');
    if (!p) { box.innerHTML = '<p class="own-empty">Pick a player on the left.</p>'; $('#own-tag').textContent = '-'; return; }
    const isActive = p.pid === activePid();
    $('#own-tag').textContent = isActive ? 'ACTIVE' : (p.banned ? 'BANNED' : 'SAVED');
    const owned = Array.isArray(p.owned) ? p.owned.length : 0;
    const rounds = Array.isArray(p.scores) ? p.scores.length : 0;
    box.innerHTML = `
      <div class="own-idbox"><b>${esc(p.pid)}</b>
        <button class="adm-btn" data-act="copy-id">COPY ID</button></div>
      <div class="own-meta">Created ${when(+p.created)} &middot; last seen ${when(+p.lastSeen)} &middot; ${owned} weapons &middot; ${rounds} saved scores</div>
      <div class="own-form">
        <label>Name<input class="adm-in" id="of-name" maxlength="14" value="${esc(p.name)}"></label>
        <label>Coins<input class="adm-in" id="of-coins" inputmode="numeric" value="${num(p.coins)}"></label>
        <label>Spin tickets<input class="adm-in" id="of-tickets" inputmode="numeric" value="${num(p.tickets)}"></label>
        <label>Gold tickets<input class="adm-in" id="of-gold" inputmode="numeric" value="${num(p.gold)}"></label>
        <label>XP<input class="adm-in" id="of-xp" inputmode="numeric" value="${num(p.xp)}"></label>
        <label>Best score<input class="adm-in" id="of-best" inputmode="numeric" value="${num(p.best)}"></label>
        <label class="own-wide">Owner note<input class="adm-in" id="of-note" maxlength="120" value="${esc(p.note)}" placeholder="only you see this"></label>
        <label class="own-chk"><input type="checkbox" id="of-pass"${p.pass ? ' checked' : ''}> Game Pass owned</label>
      </div>
      <div class="adm-row"><button class="adm-btn big own-go" data-act="save">SAVE CHANGES</button></div>
      <h4>BAN / UNBAN</h4>
      <div class="own-ban${p.banned ? ' on' : ''}">${p.banned ? 'This player is BANNED and cannot start a round.' + (p.banReason ? ' Reason: ' + esc(p.banReason) : '') : 'This player is allowed to play.'}</div>
      <div class="adm-row">
        ${p.banned
          ? '<button class="adm-btn big own-go" data-act="unban">UNBAN PLAYER</button>'
          : '<input class="adm-in own-reason" id="of-reason" maxlength="80" placeholder="Reason (optional)"><button class="adm-btn danger" data-act="ban">BAN PLAYER</button>'}
      </div>
      <h4>PLAYER ID</h4>
      <div class="adm-row">
        <input class="adm-in" id="of-newid" placeholder="FS-XXXX-XXXX" maxlength="12" spellcheck="false" autocapitalize="characters">
        <button class="adm-btn" data-act="set-id">SET ID</button>
        <button class="adm-btn warn" data-act="new-id">RANDOM NEW ID</button>
      </div>
      <h4>ACTIONS</h4>
      <div class="adm-row">
        <button class="adm-btn"${isActive ? ' disabled' : ''} data-act="switch">${isActive ? 'PLAYING AS THIS PLAYER' : 'SWITCH TO PLAYER'}</button>
        <button class="adm-btn" data-act="copy-code">COPY PLAYER CODE</button>
        <button class="adm-btn" data-act="export-one">EXPORT FILE</button>
      </div>
      <div class="adm-row">
        <button class="adm-btn warn" data-act="reset">RESET PROGRESS</button>
        <button class="adm-btn danger" data-act="delete">DELETE PLAYER</button>
      </div>`;
  }
  function renderLog() {
    $('#own-log').innerHTML = log.length ? log.slice(-8).reverse().map(l => `<div><time>${when(l.t)}</time> ${esc(l.x)}</div>`).join('') : '<div class="own-empty">Nothing yet.</div>';
  }
  function render(full) {
    FS.save();                                   // writes the active player into the roster first
    const r = readRoster();
    if (!st.sel || !r[st.sel]) st.sel = r[activePid()] ? activePid() : (Object.keys(r)[0] || null);
    renderSummary(); renderList(); renderLog();
    if (full !== false) renderDetail();
  }

  /* ---------- helpers for changing a player ---------- */
  function target(pid) {
    if (pid === activePid()) return { obj: FS.settings, active: true };
    const r = readRoster(); return r[pid] ? { obj: r[pid], active: false, r } : null;
  }
  function commit(t) {
    if (t.active) FS.refresh();                  // refresh also saves + updates the roster
    else if (!writeRoster(t.r)) toast('Could not save (storage full?)', true);
  }
  function newUnusedPid() {
    const r = readRoster(); let id;
    do { id = FS.makePid(); } while (r[id] || id === activePid());
    return id;
  }
  function changeId(old, nw) {
    nw = String(nw || '').trim().toUpperCase();
    if (!FS.PID_RE.test(nw)) throw new Error('Id must look like FS-AB12-CD34 (letters and numbers).');
    const r = readRoster();
    if (nw === old) throw new Error('That is already this player id.');
    if (r[nw] || nw === activePid()) throw new Error('That id belongs to another player.');
    const fix = o => (Array.isArray(o.scores) ? o.scores : []).forEach(e => { if (e && e.pid === old) e.pid = nw; });
    if (old === activePid()) {
      fix(FS.settings); FS.settings.pid = nw; delete r[old]; writeRoster(r); FS.refresh();
    } else {
      const o = r[old]; if (!o) throw new Error('Player not found.');
      fix(o); o.pid = nw; delete r[old]; r[nw] = o; writeRoster(r);
    }
    addLog('Changed id ' + old + ' to ' + nw);
    st.sel = nw;
  }
  function download(name, text) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  const encode = p => CODE_PREFIX + btoa(unescape(encodeURIComponent(JSON.stringify(p)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  function decode(s) {
    s = s.trim().slice(CODE_PREFIX.length).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return JSON.parse(decodeURIComponent(escape(atob(s))));
  }
  async function copy(text, ok) {
    try { await navigator.clipboard.writeText(text); toast(ok); }
    catch (e) {
      const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); toast(ok); } catch (e2) { toast('Copy failed - select the text manually', true); }
      ta.remove();
    }
  }
  const val = id => $('#' + id, panel).value;

  function doImport() {
    const text = $('#own-code').value.trim();
    if (!text) return toast('Paste a player code or choose a file first', true);
    if (text.length > 5e6) return toast('That is too big to import', true);
    const incoming = [];
    try {
      if (text[0] === '{') {
        const o = JSON.parse(text);
        if (o && o.players && typeof o.players === 'object') Object.keys(o.players).forEach(k => incoming.push(o.players[k]));
        else incoming.push(o);
      } else {
        text.split(/\s+/).filter(Boolean).forEach(l => { if (l.indexOf(CODE_PREFIX) === 0) incoming.push(decode(l)); });
      }
    } catch (e) { return toast('Could not read that data', true); }
    if (!incoming.length) return toast('No player data found', true);
    const r = readRoster(), over = $('#own-over').checked;
    let added = 0, updated = 0, skipped = 0, bad = 0;
    incoming.slice(0, MAX_IMPORT).forEach(raw => {
      const c = clean(raw);
      if (!c) { bad++; return; }
      if (c.pid === activePid()) { skipped++; return; }          // switch to this player first to replace the active one
      if (r[c.pid]) {
        if (over || (+c.lastSeen || 0) > (+r[c.pid].lastSeen || 0)) { r[c.pid] = c; updated++; } else skipped++;
      } else { r[c.pid] = c; added++; }
    });
    if (!writeRoster(r)) return toast('Could not save (storage full?)', true);
    addLog('Import: ' + added + ' new, ' + updated + ' updated, ' + skipped + ' skipped, ' + bad + ' invalid');
    toast(added + ' new, ' + updated + ' updated, ' + skipped + ' skipped' + (bad ? ', ' + bad + ' invalid' : ''), !added && !updated);
    if (added || updated) { $('#own-code').value = ''; }
    render();
  }

  /* ---------- clicks ---------- */
  panel.addEventListener('click', e => {
    const row = e.target.closest('.own-row');
    if (row) { st.sel = row.dataset.pid; renderList(); renderDetail(); return; }
    const b = e.target.closest('[data-act]'); if (!b) return;
    const act = b.dataset.act, pid = st.sel, t = pid && target(pid);
    try {
      switch (act) {
        case 'new': { FS.useProfile({}); st.sel = activePid(); addLog('Created player ' + st.sel); toast('New player ' + st.sel); render(); break; }
        case 'export-all': {
          FS.save();
          download('fruit-slash-players.json', JSON.stringify({ format: 'fruit-slash-players', version: 1, exported: Date.now(), players: readRoster() }, null, 1));
          addLog('Exported all players'); renderLog(); toast('Exported'); break;
        }
        case 'toggle-import': { const im = $('#own-import'); im.hidden = !im.hidden; break; }
        case 'pick-file': $('#own-file').click(); break;
        case 'import': doImport(); break;
        case 'copy-id': copy(pid, 'Player id copied'); break;
        case 'copy-code': { if (!t) break; render(false); copy(encode(readRoster()[pid]), 'Player code copied'); break; }
        case 'export-one': { if (!t) break; render(false); download('player-' + pid + '.json', JSON.stringify(readRoster()[pid], null, 1)); toast('Exported'); break; }
        case 'save': {
          if (!t) break;
          const o = t.obj;
          o.name = (val('of-name').trim() || 'Player').slice(0, 14);
          o.coins = num(val('of-coins')); o.tickets = num(val('of-tickets')); o.gold = num(val('of-gold'));
          o.xp = num(val('of-xp')); o.best = num(val('of-best'));
          o.note = val('of-note').slice(0, 120);
          o.pass = $('#of-pass', panel).checked;
          commit(t); addLog('Edited ' + pid); toast('Saved'); render(); break;
        }
        case 'filter': { st.f = b.dataset.f; $$('.own-f', panel).forEach(x => x.classList.toggle('on', x === b)); renderList(); break; }
        case 'ban': {
          if (!t) break;
          t.obj.banned = true; t.obj.banReason = val('of-reason').trim().slice(0, 80);
          commit(t); addLog('Banned ' + pid + (t.obj.banReason ? ' - ' + t.obj.banReason : '')); toast('Player banned'); render(); break;
        }
        case 'unban': {
          if (!t) break;
          t.obj.banned = false; t.obj.banReason = '';
          commit(t); addLog('Unbanned ' + pid); toast('Player unbanned'); render(); break;
        }
        case 'unban-all': {
          const r = readRoster(), ids = Object.keys(r).filter(k => r[k] && r[k].banned);
          if (!ids.length) { toast('Nobody is banned'); break; }
          if (!confirm('Unban all ' + ids.length + ' banned players?')) break;
          ids.forEach(k => { r[k].banned = false; r[k].banReason = ''; });
          writeRoster(r);
          if (FS.settings.banned) { FS.settings.banned = false; FS.settings.banReason = ''; FS.refresh(); }
          addLog('Unbanned all (' + ids.length + ')'); toast(ids.length + ' players unbanned'); render(); break;
        }
        case 'set-id': changeId(pid, val('of-newid')); toast('Player id changed'); render(); break;
        case 'new-id': { const nid = newUnusedPid(); changeId(pid, nid); toast('New id ' + nid); render(); break; }
        case 'switch': { if (!t || t.active) break; FS.useProfile(t.obj); st.sel = activePid(); addLog('Switched to ' + st.sel); toast('Now playing as ' + st.sel); render(); break; }
        case 'reset': {
          if (!t || !confirm('Reset all progress for ' + pid + '? The id, name and note stay.')) break;
          const keep = { pid, name: t.obj.name, note: t.obj.note, banned: t.obj.banned, created: t.obj.created };
          if (t.active) FS.useProfile(keep);
          else { t.r[pid] = Object.assign(JSON.parse(JSON.stringify(FS.DEFAULTS)), keep, { lastSeen: Date.now() }); writeRoster(t.r); }
          addLog('Reset progress for ' + pid); toast('Progress reset'); render(); break;
        }
        case 'delete': {
          if (!t || !confirm('Delete player ' + pid + ' and all of its data? This cannot be undone.')) break;
          if (t.active) {
            const r = readRoster(); delete r[pid]; writeRoster(r);
            FS.useProfile({}); st.sel = activePid();            // the device always needs an active player
          } else { delete t.r[pid]; writeRoster(t.r); st.sel = null; }
          addLog('Deleted player ' + pid); toast('Player deleted'); render(); break;
        }
      }
    } catch (err) { toast(err.message || 'Something went wrong', true); }
  });
  $('#own-q', panel).addEventListener('input', e => { st.q = e.target.value; renderList(); });
  $('#own-file', panel).addEventListener('change', e => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    if (f.size > 5e6) { toast('That file is too big', true); return; }
    const rd = new FileReader();
    rd.onload = () => { $('#own-code').value = String(rd.result || ''); toast('File loaded - press IMPORT PLAYERS'); };
    rd.readAsText(f); e.target.value = '';
  });

  /* ---------- tab + shortcut ---------- */
  // admin.js switches tabs from a click on the tab bar (it matches data-tab to data-panel), so a click is enough
  tabBtn.addEventListener('click', () => render());
  window.addEventListener('keydown', e => {
    if (root.hidden || !e.altKey || e.key !== '5') return;
    const main = $('#adm-main'); if (!main || main.hidden) return;
    e.preventDefault(); e.stopImmediatePropagation(); tabBtn.click();
  }, true);
})();
